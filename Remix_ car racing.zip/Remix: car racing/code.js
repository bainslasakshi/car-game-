var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["40c37673-ba89-4d05-858c-34f9bf73e309","3a50f5d6-97c8-4b65-b4a7-6c079cc0217e","a6e39568-315c-412c-991a-5361d71efd0d","9c78789e-c3e0-41ea-8489-aab6acc57b18","6f131a00-180d-4e81-ad17-a6f52f09e800","073ad7fb-ea7c-4e85-9b4c-ef745f4d01b2","0456cd00-512a-493d-89e3-6b001adf00ba","9e3ee613-88d3-4887-a9df-499f1d41e6bf","f2afbf26-e433-497e-9ad8-4746925082b5","92c3320f-2ded-4e98-88b1-915907fc733c","de19e61b-8d41-4969-902f-4698552f0756","3cef6a74-ec28-49e1-9fc3-05c5d7472769","dd6cd836-5686-498d-a1a1-c7d516064c66","dcd1f27b-873d-4156-a863-af857e577f66","3c8868f9-ab3a-4bd8-a263-aa38d00c8b1f","ae4826eb-dbbe-4098-abc6-edf1189e1a6d","004abded-77b9-493a-ab12-21bd13b5a84f","76016573-d572-4fc6-9a98-0e2a6bfa02aa","0930d7a5-5cc8-40b2-aa45-4e4db7dc6a61","67563a96-4a69-49e7-8759-4774d42b17ab","67675b13-6898-4873-9cd6-b4ee4aaca354","ee7f9b1a-2a7c-45c1-9cf2-292a43896f3b","8129159b-0610-452e-9997-1e900a076fe0","801f880b-c86a-48f8-a98d-640a912981be","273aec08-ff79-4cfb-a673-8d07bfbbcda8","8d58b7d7-4a76-4fac-9b1e-f7d076543cdc","4ec07763-bbe8-4641-aa03-38b20d5986b1","bb467ccc-44df-40d5-bfc9-c3af83378da2","87c71ef1-3fdc-4e68-bf36-e0c5d1268724","7af8dfc4-b58f-42c9-9bd5-b314cdc36b20","07fe9f84-e733-4194-af6a-fe4d88ad6df2","b0fd03c6-a9f4-4d20-b2f3-5c7cbd611f90","f47c41cb-8579-49b4-861d-4f6e1d6646d9","37aec8b7-a342-46d6-92c8-95364da3452a","cb474c54-9e90-4620-8f7f-1136b0741d98","c6c73713-2ec9-448c-b628-5415bb97c722","1c6cf23d-a44b-4010-9f8d-d2203ea805d8","75fbd4a2-5279-4383-bf04-f0cd22773ae8","af21a2cc-3124-4b66-a1f7-84f1f0e15d6a","eaa4a34f-d56e-4180-8bf9-4ab853fa42b7","a5f1626d-8c1a-46fb-b81c-db36e543cd13","bca3d2ae-118e-42a8-a132-fee3f2506c0a","8de75247-ee1e-42f9-8572-55f062300b48","029a468a-1e90-405f-b309-4526c86a5389","4f07fb90-6aba-4ab7-b0a9-8e6894ed8098","d24bc207-4994-4cc8-823f-6354979bc350","3fb8c63c-2b57-44b6-a2a5-f6136b3163bd","a8aad91c-a7a5-4890-9553-5e16a5202e4c","e7cd5b3e-e9c5-4279-8af8-79fdc5d76a89","adb21f2b-2168-4d86-b045-c6600ecab669","ebfa93c2-19f1-470a-b300-3f7b028c2921","8f9de5ef-3705-4f62-bbc5-cb8367830a5b","88a4deb6-728c-4fd0-92b4-b324b57fe517","e237296d-399f-4552-9460-b8a1cd937ba5","e2bd9b27-b33f-43ef-ac1e-e2fe0fb95bca","d4f355e8-87d6-4a28-ab71-447c1195ef98","f2f19110-e15a-495b-a72c-684373a4636c","e8f554bf-bf19-48a6-849f-88d4dd4b91a1","fd0766a5-03c9-45d6-bc4c-d6cbbef3b6ef","b01611f2-c22e-47a0-9e3d-a88c1b22fc5b","97589118-4ede-44de-9dba-30b993e56fe9","022ffebb-2da2-417f-b308-4addc2fca896","c9d1fdc7-589f-48d0-a92b-14421025f68b","66b661d0-c187-4546-81c7-3d502a8815c0","a5dbf601-b7cd-4062-9a18-5fbb46e91c0b","0980b13e-c6e7-4ca3-8c74-a528a4b98185","40663659-3a93-4e34-915c-f0775f93c71a","c2c19eba-9c80-4feb-a776-53b1002362f0","3781ed3f-c843-4084-a2cd-ee973c280186","a8aaa767-454e-4526-ab5d-d9496ffc778a","46b1cb56-ba08-4a74-9896-ba322d82b6fe","f84252f0-fea6-48a5-ad8d-7a1e6fe8d373","356d4514-37c6-48f8-9b73-c61ea025fbec","80ad3ecc-8556-4554-b5bf-cad095c9683a","2388cac9-2503-46b7-8bd9-fa84761e8cd4","f5e8bd44-dbad-4fef-bd49-f318512c33cd","10d5166e-aa72-4bd9-82ad-36acdfa66b7b","7f780ccc-66d0-46f4-90ca-1c2618e71376","68eb9ed5-0949-4f73-b4bf-896a17a21f1b","f604c740-e0d6-4f1a-9796-67655635eacb","5f337ac4-92ae-43c8-b8f1-1ac77a09bfb2"],"propsByKey":{"40c37673-ba89-4d05-858c-34f9bf73e309":{"name":"jetpack","sourceUrl":null,"frameSize":{"x":133,"y":158},"frameCount":1,"looping":true,"frameDelay":12,"version":"FlPGETm84X.cdASAz3BAM7l5ryafE7A3","loadedFromSource":true,"saved":true,"sourceSize":{"x":133,"y":158},"rootRelativePath":"assets/40c37673-ba89-4d05-858c-34f9bf73e309.png"},"3a50f5d6-97c8-4b65-b4a7-6c079cc0217e":{"name":"jetpack_copy_1","sourceUrl":null,"frameSize":{"x":49,"y":157},"frameCount":1,"looping":true,"frameDelay":12,"version":"x2Ht4GysVhpC_ilcKu9bdWJGA0orZZK.","loadedFromSource":true,"saved":true,"sourceSize":{"x":49,"y":157},"rootRelativePath":"assets/3a50f5d6-97c8-4b65-b4a7-6c079cc0217e.png"},"a6e39568-315c-412c-991a-5361d71efd0d":{"name":"super speed","sourceUrl":null,"frameSize":{"x":73,"y":156},"frameCount":1,"looping":true,"frameDelay":12,"version":"1hX3Gih_deQr1ug1XY4aDSbhzQoq1ich","loadedFromSource":true,"saved":true,"sourceSize":{"x":73,"y":156},"rootRelativePath":"assets/a6e39568-315c-412c-991a-5361d71efd0d.png"},"9c78789e-c3e0-41ea-8489-aab6acc57b18":{"name":"I'm your superpowers","sourceUrl":null,"frameSize":{"x":242,"y":225},"frameCount":6,"looping":true,"frameDelay":2,"version":"3bZKlVAsDDj.vI6QNC7ZVuWTqybIrU58","loadedFromSource":true,"saved":true,"sourceSize":{"x":484,"y":675},"rootRelativePath":"assets/9c78789e-c3e0-41ea-8489-aab6acc57b18.png"},"6f131a00-180d-4e81-ad17-a6f52f09e800":{"name":"green","sourceUrl":null,"frameSize":{"x":70,"y":131},"frameCount":1,"looping":true,"frameDelay":12,"version":"Og5AamN7EIApkTN2zgkTTuNmQc.qfhUR","loadedFromSource":true,"saved":true,"sourceSize":{"x":70,"y":131},"rootRelativePath":"assets/6f131a00-180d-4e81-ad17-a6f52f09e800.png"},"073ad7fb-ea7c-4e85-9b4c-ef745f4d01b2":{"name":"greencrash1","sourceUrl":null,"frameSize":{"x":70,"y":131},"frameCount":1,"looping":true,"frameDelay":12,"version":"4MC6hwG4ZwYdIdQfTq0jYG7uaAQJCJhp","loadedFromSource":true,"saved":true,"sourceSize":{"x":70,"y":131},"rootRelativePath":"assets/073ad7fb-ea7c-4e85-9b4c-ef745f4d01b2.png"},"0456cd00-512a-493d-89e3-6b001adf00ba":{"name":"perfect hit 1","sourceUrl":null,"frameSize":{"x":70,"y":131},"frameCount":1,"looping":true,"frameDelay":12,"version":"OUuxu.sMRDbAyzo7O_JSW3R6mH4np4Rz","loadedFromSource":true,"saved":true,"sourceSize":{"x":70,"y":131},"rootRelativePath":"assets/0456cd00-512a-493d-89e3-6b001adf00ba.png"},"9e3ee613-88d3-4887-a9df-499f1d41e6bf":{"name":"yellow","sourceUrl":null,"frameSize":{"x":70,"y":120},"frameCount":1,"looping":true,"frameDelay":12,"version":"4l0svRn92cPPihbAInlaXHnl_Ftj6npJ","loadedFromSource":true,"saved":true,"sourceSize":{"x":70,"y":120},"rootRelativePath":"assets/9e3ee613-88d3-4887-a9df-499f1d41e6bf.png"},"f2afbf26-e433-497e-9ad8-4746925082b5":{"name":"yellowcrash1","sourceUrl":null,"frameSize":{"x":70,"y":120},"frameCount":1,"looping":true,"frameDelay":12,"version":"JQN4zcA9Q7PkHTSm.TAcNmNpSB51xw8C","loadedFromSource":true,"saved":true,"sourceSize":{"x":70,"y":120},"rootRelativePath":"assets/f2afbf26-e433-497e-9ad8-4746925082b5.png"},"92c3320f-2ded-4e98-88b1-915907fc733c":{"name":"perfect hit 2","sourceUrl":null,"frameSize":{"x":70,"y":120},"frameCount":1,"looping":true,"frameDelay":12,"version":"p.YblSvr7Z.Lr2CFUUJWXBERFLe35lCy","loadedFromSource":true,"saved":true,"sourceSize":{"x":70,"y":120},"rootRelativePath":"assets/92c3320f-2ded-4e98-88b1-915907fc733c.png"},"de19e61b-8d41-4969-902f-4698552f0756":{"name":"black","sourceUrl":null,"frameSize":{"x":71,"y":131},"frameCount":1,"looping":true,"frameDelay":12,"version":"Rj9ha3qOUXYrqE2W.0VHJntWPnr1Caz5","loadedFromSource":true,"saved":true,"sourceSize":{"x":71,"y":131},"rootRelativePath":"assets/de19e61b-8d41-4969-902f-4698552f0756.png"},"3cef6a74-ec28-49e1-9fc3-05c5d7472769":{"name":"blackcrash1","sourceUrl":null,"frameSize":{"x":71,"y":131},"frameCount":1,"looping":true,"frameDelay":12,"version":"j7hXXbjapmUjHLhG7B6ezK2LxLTUExaf","loadedFromSource":true,"saved":true,"sourceSize":{"x":71,"y":131},"rootRelativePath":"assets/3cef6a74-ec28-49e1-9fc3-05c5d7472769.png"},"dd6cd836-5686-498d-a1a1-c7d516064c66":{"name":"lightgreen","sourceUrl":null,"frameSize":{"x":77,"y":179},"frameCount":1,"looping":true,"frameDelay":12,"version":"dOczrIClzMj2ZkqQ55pgJFAcAgZmNlzV","loadedFromSource":true,"saved":true,"sourceSize":{"x":77,"y":179},"rootRelativePath":"assets/dd6cd836-5686-498d-a1a1-c7d516064c66.png"},"dcd1f27b-873d-4156-a863-af857e577f66":{"name":"lightyellow","sourceUrl":null,"frameSize":{"x":77,"y":179},"frameCount":1,"looping":true,"frameDelay":12,"version":"lMf0C7Hn8k9g8JaeMLtKvf.DQiNFJF4f","loadedFromSource":true,"saved":true,"sourceSize":{"x":77,"y":179},"rootRelativePath":"assets/dcd1f27b-873d-4156-a863-af857e577f66.png"},"3c8868f9-ab3a-4bd8-a263-aa38d00c8b1f":{"name":"lightred","sourceUrl":null,"frameSize":{"x":77,"y":180},"frameCount":1,"looping":true,"frameDelay":12,"version":"IlZRD4igPHZ6KsBYfS98sUnLzLwu.xYm","loadedFromSource":true,"saved":true,"sourceSize":{"x":77,"y":180},"rootRelativePath":"assets/3c8868f9-ab3a-4bd8-a263-aa38d00c8b1f.png"},"ae4826eb-dbbe-4098-abc6-edf1189e1a6d":{"name":"coin","sourceUrl":"assets/api/v1/animation-library/uqjnPX34Zq4tu_YRF_P_sAQ28huvzwwX/category_gameplay/bronze.png","frameSize":{"x":86,"y":86},"frameCount":6,"looping":true,"frameDelay":2,"version":"uqjnPX34Zq4tu_YRF_P_sAQ28huvzwwX","loadedFromSource":true,"saved":true,"sourceSize":{"x":516,"y":86},"rootRelativePath":"assets/api/v1/animation-library/uqjnPX34Zq4tu_YRF_P_sAQ28huvzwwX/category_gameplay/bronze.png"},"004abded-77b9-493a-ab12-21bd13b5a84f":{"name":"grass","sourceUrl":null,"frameSize":{"x":128,"y":128},"frameCount":2,"looping":true,"frameDelay":10,"version":"o_99uGlJaXMoLBr0RLHnjdNa1g0tYFZz","loadedFromSource":true,"saved":true,"sourceSize":{"x":128,"y":256},"rootRelativePath":"assets/004abded-77b9-493a-ab12-21bd13b5a84f.png"},"76016573-d572-4fc6-9a98-0e2a6bfa02aa":{"name":"dirt","sourceUrl":null,"frameSize":{"x":128,"y":128},"frameCount":2,"looping":true,"frameDelay":12,"version":"7_WavU4PByGh9.dByDhC0NQC.g_cbozZ","loadedFromSource":true,"saved":true,"sourceSize":{"x":128,"y":256},"rootRelativePath":"assets/76016573-d572-4fc6-9a98-0e2a6bfa02aa.png"},"0930d7a5-5cc8-40b2-aa45-4e4db7dc6a61":{"name":"sand","sourceUrl":null,"frameSize":{"x":128,"y":128},"frameCount":2,"looping":true,"frameDelay":12,"version":"GWqO1ALfYiM_tBFvHSehZ8u9l5RGSUPQ","loadedFromSource":true,"saved":true,"sourceSize":{"x":128,"y":256},"rootRelativePath":"assets/0930d7a5-5cc8-40b2-aa45-4e4db7dc6a61.png"},"67563a96-4a69-49e7-8759-4774d42b17ab":{"name":"redsand","sourceUrl":null,"frameSize":{"x":128,"y":128},"frameCount":2,"looping":true,"frameDelay":12,"version":"keF4gTycYx3BiKIIfZBAoHv1MiUOxWY1","loadedFromSource":true,"saved":true,"sourceSize":{"x":128,"y":256},"rootRelativePath":"assets/67563a96-4a69-49e7-8759-4774d42b17ab.png"},"67675b13-6898-4873-9cd6-b4ee4aaca354":{"name":"snow","sourceUrl":null,"frameSize":{"x":128,"y":128},"frameCount":2,"looping":true,"frameDelay":12,"version":"qqQTvea1eSoDYofDWxrFdI.1w60fxiEH","loadedFromSource":true,"saved":true,"sourceSize":{"x":128,"y":256},"rootRelativePath":"assets/67675b13-6898-4873-9cd6-b4ee4aaca354.png"},"ee7f9b1a-2a7c-45c1-9cf2-292a43896f3b":{"name":"lake","sourceUrl":null,"frameSize":{"x":128,"y":128},"frameCount":2,"looping":true,"frameDelay":12,"version":"gLzT_Oq0Al0maCuV2IpF5e5lQhps038e","loadedFromSource":true,"saved":true,"sourceSize":{"x":128,"y":256},"rootRelativePath":"assets/ee7f9b1a-2a7c-45c1-9cf2-292a43896f3b.png"},"8129159b-0610-452e-9997-1e900a076fe0":{"name":"grass1","sourceUrl":null,"frameSize":{"x":58,"y":62},"frameCount":1,"looping":true,"frameDelay":12,"version":"ZhuLagZAtx8grgJJTVUWB.BMyELnbIGc","loadedFromSource":true,"saved":true,"sourceSize":{"x":58,"y":62},"rootRelativePath":"assets/8129159b-0610-452e-9997-1e900a076fe0.png"},"801f880b-c86a-48f8-a98d-640a912981be":{"name":"grass2","sourceUrl":null,"frameSize":{"x":82,"y":73},"frameCount":1,"looping":true,"frameDelay":12,"version":"ziHmoerBQEe_T7v.DOBjkxxDxBQqioAC","loadedFromSource":true,"saved":true,"sourceSize":{"x":82,"y":73},"rootRelativePath":"assets/801f880b-c86a-48f8-a98d-640a912981be.png"},"273aec08-ff79-4cfb-a673-8d07bfbbcda8":{"name":"grass3","sourceUrl":null,"frameSize":{"x":50,"y":95},"frameCount":1,"looping":true,"frameDelay":12,"version":"tzlmUVhr0_qNkFHpZp7O8s.ohLle0_q7","loadedFromSource":true,"saved":true,"sourceSize":{"x":50,"y":95},"rootRelativePath":"assets/273aec08-ff79-4cfb-a673-8d07bfbbcda8.png"},"8d58b7d7-4a76-4fac-9b1e-f7d076543cdc":{"name":"grassbrown1","sourceUrl":null,"frameSize":{"x":57,"y":54},"frameCount":1,"looping":true,"frameDelay":12,"version":"FYks3im9k1Wr38FiHiAQOwWIKs49o2BI","loadedFromSource":true,"saved":true,"sourceSize":{"x":57,"y":54},"rootRelativePath":"assets/8d58b7d7-4a76-4fac-9b1e-f7d076543cdc.png"},"4ec07763-bbe8-4641-aa03-38b20d5986b1":{"name":"grassbrown2","sourceUrl":null,"frameSize":{"x":82,"y":65},"frameCount":1,"looping":true,"frameDelay":12,"version":"zopcwXEDzBLGdpfRqcVYpq0k9zwzbt6U","loadedFromSource":true,"saved":true,"sourceSize":{"x":82,"y":65},"rootRelativePath":"assets/4ec07763-bbe8-4641-aa03-38b20d5986b1.png"},"bb467ccc-44df-40d5-bfc9-c3af83378da2":{"name":"cactus","sourceUrl":"assets/api/v1/animation-library/Upmg1FkAg98o2Ts1y62_qkpGKH03EsXY/category_obstacles/cactus.png","frameSize":{"x":117,"y":160},"frameCount":1,"looping":true,"frameDelay":2,"version":"Upmg1FkAg98o2Ts1y62_qkpGKH03EsXY","loadedFromSource":true,"saved":true,"sourceSize":{"x":117,"y":160},"rootRelativePath":"assets/api/v1/animation-library/Upmg1FkAg98o2Ts1y62_qkpGKH03EsXY/category_obstacles/cactus.png"},"87c71ef1-3fdc-4e68-bf36-e0c5d1268724":{"name":"diamond","sourceUrl":null,"frameSize":{"x":56,"y":56},"frameCount":1,"looping":true,"frameDelay":12,"version":"1GUHQ6p6AHebEfiBJuA19vaLxk.X6GOT","loadedFromSource":true,"saved":true,"sourceSize":{"x":56,"y":56},"rootRelativePath":"assets/87c71ef1-3fdc-4e68-bf36-e0c5d1268724.png"},"7af8dfc4-b58f-42c9-9bd5-b314cdc36b20":{"name":"wheat","sourceUrl":null,"frameSize":{"x":107,"y":124},"frameCount":1,"looping":true,"frameDelay":12,"version":"m8AebzFdVpuA6ElDz38G.zF9p8fbCEQM","loadedFromSource":true,"saved":true,"sourceSize":{"x":107,"y":124},"rootRelativePath":"assets/7af8dfc4-b58f-42c9-9bd5-b314cdc36b20.png"},"07fe9f84-e733-4194-af6a-fe4d88ad6df2":{"name":"seed","sourceUrl":null,"frameSize":{"x":62,"y":69},"frameCount":1,"looping":true,"frameDelay":12,"version":"kM8FuES37.b_6doqqeqVgCfswWtIrLzl","loadedFromSource":true,"saved":true,"sourceSize":{"x":62,"y":69},"rootRelativePath":"assets/07fe9f84-e733-4194-af6a-fe4d88ad6df2.png"},"b0fd03c6-a9f4-4d20-b2f3-5c7cbd611f90":{"name":"road1","sourceUrl":null,"frameSize":{"x":280,"y":180},"frameCount":1,"looping":true,"frameDelay":12,"version":"FuYHSles6Y_4nLJI_fsTUbJLoI.mMw0G","loadedFromSource":true,"saved":true,"sourceSize":{"x":280,"y":180},"rootRelativePath":"assets/b0fd03c6-a9f4-4d20-b2f3-5c7cbd611f90.png"},"f47c41cb-8579-49b4-861d-4f6e1d6646d9":{"name":"road2","sourceUrl":null,"frameSize":{"x":280,"y":180},"frameCount":2,"looping":true,"frameDelay":10,"version":"7NlWunCDG.VSqVDG48_v2S48h_5sFx6I","loadedFromSource":true,"saved":true,"sourceSize":{"x":280,"y":360},"rootRelativePath":"assets/f47c41cb-8579-49b4-861d-4f6e1d6646d9.png"},"37aec8b7-a342-46d6-92c8-95364da3452a":{"name":"road4","sourceUrl":null,"frameSize":{"x":280,"y":180},"frameCount":2,"looping":true,"frameDelay":5,"version":"RBR0zkNVvhOiKA.auianS_ZID4t2Dwea","loadedFromSource":true,"saved":true,"sourceSize":{"x":280,"y":360},"rootRelativePath":"assets/37aec8b7-a342-46d6-92c8-95364da3452a.png"},"cb474c54-9e90-4620-8f7f-1136b0741d98":{"name":"road5","sourceUrl":null,"frameSize":{"x":280,"y":180},"frameCount":2,"looping":true,"frameDelay":4,"version":"BvmrltZLrP6kjU4sxHxoNUyCJoMRWzS3","loadedFromSource":true,"saved":true,"sourceSize":{"x":280,"y":360},"rootRelativePath":"assets/cb474c54-9e90-4620-8f7f-1136b0741d98.png"},"c6c73713-2ec9-448c-b628-5415bb97c722":{"name":"road6","sourceUrl":null,"frameSize":{"x":280,"y":180},"frameCount":2,"looping":true,"frameDelay":3,"version":"0GYQ8HqBe.eXD5QSQZ2dcNW8gCKHjR.R","loadedFromSource":true,"saved":true,"sourceSize":{"x":280,"y":360},"rootRelativePath":"assets/c6c73713-2ec9-448c-b628-5415bb97c722.png"},"1c6cf23d-a44b-4010-9f8d-d2203ea805d8":{"name":"road3","sourceUrl":null,"frameSize":{"x":280,"y":180},"frameCount":2,"looping":true,"frameDelay":15,"version":"Qth4ss8AR2KQcqftR.Y7quxgItA.lOIQ","loadedFromSource":true,"saved":true,"sourceSize":{"x":280,"y":360},"rootRelativePath":"assets/1c6cf23d-a44b-4010-9f8d-d2203ea805d8.png"},"75fbd4a2-5279-4383-bf04-f0cd22773ae8":{"name":"empty1","sourceUrl":null,"frameSize":{"x":50,"y":36},"frameCount":1,"looping":true,"frameDelay":12,"version":"RMF9ki2JszI.xsKBQeCGkrV_6ssa6G4E","loadedFromSource":true,"saved":true,"sourceSize":{"x":50,"y":36},"rootRelativePath":"assets/75fbd4a2-5279-4383-bf04-f0cd22773ae8.png"},"af21a2cc-3124-4b66-a1f7-84f1f0e15d6a":{"name":"empty2","sourceUrl":null,"frameSize":{"x":50,"y":36},"frameCount":1,"looping":true,"frameDelay":12,"version":"3tfNQjlEHrq_A9a8CtoRTlUjCUS9OdnR","loadedFromSource":true,"saved":true,"sourceSize":{"x":50,"y":36},"rootRelativePath":"assets/af21a2cc-3124-4b66-a1f7-84f1f0e15d6a.png"},"eaa4a34f-d56e-4180-8bf9-4ab853fa42b7":{"name":"low1","sourceUrl":null,"frameSize":{"x":50,"y":36},"frameCount":1,"looping":true,"frameDelay":12,"version":"zGf49OaDN6k9RjCVsboo2L46u4gsoftm","loadedFromSource":true,"saved":true,"sourceSize":{"x":50,"y":36},"rootRelativePath":"assets/eaa4a34f-d56e-4180-8bf9-4ab853fa42b7.png"},"a5f1626d-8c1a-46fb-b81c-db36e543cd13":{"name":"low2","sourceUrl":null,"frameSize":{"x":50,"y":36},"frameCount":1,"looping":true,"frameDelay":12,"version":"zIu6o3KB_0LD_VUgFVEBcbYZkBNCVZpk","loadedFromSource":true,"saved":true,"sourceSize":{"x":50,"y":36},"rootRelativePath":"assets/a5f1626d-8c1a-46fb-b81c-db36e543cd13.png"},"bca3d2ae-118e-42a8-a132-fee3f2506c0a":{"name":"low3","sourceUrl":null,"frameSize":{"x":50,"y":36},"frameCount":1,"looping":true,"frameDelay":12,"version":"6LUvA7RomXiKD78mHXK3_1VIHGEjTi9C","loadedFromSource":true,"saved":true,"sourceSize":{"x":50,"y":36},"rootRelativePath":"assets/bca3d2ae-118e-42a8-a132-fee3f2506c0a.png"},"8de75247-ee1e-42f9-8572-55f062300b48":{"name":"m1","sourceUrl":null,"frameSize":{"x":50,"y":36},"frameCount":1,"looping":true,"frameDelay":12,"version":"r0nWmlNzmWcpex38_PPem60FwQW3uSXJ","loadedFromSource":true,"saved":true,"sourceSize":{"x":50,"y":36},"rootRelativePath":"assets/8de75247-ee1e-42f9-8572-55f062300b48.png"},"029a468a-1e90-405f-b309-4526c86a5389":{"name":"m2","sourceUrl":null,"frameSize":{"x":50,"y":36},"frameCount":1,"looping":true,"frameDelay":12,"version":"0fQ51O1IziD_rvYAxsvI2yf04tg02deZ","loadedFromSource":true,"saved":true,"sourceSize":{"x":50,"y":36},"rootRelativePath":"assets/029a468a-1e90-405f-b309-4526c86a5389.png"},"4f07fb90-6aba-4ab7-b0a9-8e6894ed8098":{"name":"m3","sourceUrl":null,"frameSize":{"x":50,"y":36},"frameCount":1,"looping":true,"frameDelay":12,"version":"SIbsV8QHjz6aj.SECCuhfAYhgGpM57_u","loadedFromSource":true,"saved":true,"sourceSize":{"x":50,"y":36},"rootRelativePath":"assets/4f07fb90-6aba-4ab7-b0a9-8e6894ed8098.png"},"d24bc207-4994-4cc8-823f-6354979bc350":{"name":"m4","sourceUrl":null,"frameSize":{"x":50,"y":36},"frameCount":1,"looping":true,"frameDelay":12,"version":"0MVBT0Iyi7ubhIittRzzBYop_gD8.YSi","loadedFromSource":true,"saved":true,"sourceSize":{"x":50,"y":36},"rootRelativePath":"assets/d24bc207-4994-4cc8-823f-6354979bc350.png"},"3fb8c63c-2b57-44b6-a2a5-f6136b3163bd":{"name":"high1","sourceUrl":null,"frameSize":{"x":50,"y":36},"frameCount":1,"looping":true,"frameDelay":12,"version":"8YUFlmA4t9Jfv9833u7Y4mVwXI8_cVuJ","loadedFromSource":true,"saved":true,"sourceSize":{"x":50,"y":36},"rootRelativePath":"assets/3fb8c63c-2b57-44b6-a2a5-f6136b3163bd.png"},"a8aad91c-a7a5-4890-9553-5e16a5202e4c":{"name":"high2","sourceUrl":null,"frameSize":{"x":50,"y":36},"frameCount":1,"looping":true,"frameDelay":12,"version":"CWUdOFGww7_HUduG5Z0zx8Zp6rL5LK5h","loadedFromSource":true,"saved":true,"sourceSize":{"x":50,"y":36},"rootRelativePath":"assets/a8aad91c-a7a5-4890-9553-5e16a5202e4c.png"},"e7cd5b3e-e9c5-4279-8af8-79fdc5d76a89":{"name":"high3","sourceUrl":null,"frameSize":{"x":50,"y":36},"frameCount":1,"looping":true,"frameDelay":12,"version":"xJqVloTrOESXkduE66OTalt.lUnr07Hv","loadedFromSource":true,"saved":true,"sourceSize":{"x":50,"y":36},"rootRelativePath":"assets/e7cd5b3e-e9c5-4279-8af8-79fdc5d76a89.png"},"adb21f2b-2168-4d86-b045-c6600ecab669":{"name":"high4","sourceUrl":null,"frameSize":{"x":50,"y":36},"frameCount":1,"looping":true,"frameDelay":12,"version":"ZRXCKJ.Og1fdVnj1wv1vvakBQVxAOff.","loadedFromSource":true,"saved":true,"sourceSize":{"x":50,"y":36},"rootRelativePath":"assets/adb21f2b-2168-4d86-b045-c6600ecab669.png"},"ebfa93c2-19f1-470a-b300-3f7b028c2921":{"name":"high5","sourceUrl":null,"frameSize":{"x":50,"y":36},"frameCount":1,"looping":true,"frameDelay":12,"version":"zEp467ygtnrzcUqjN66TdPESzflp5rMc","loadedFromSource":true,"saved":true,"sourceSize":{"x":50,"y":36},"rootRelativePath":"assets/ebfa93c2-19f1-470a-b300-3f7b028c2921.png"},"8f9de5ef-3705-4f62-bbc5-cb8367830a5b":{"name":"high6","sourceUrl":null,"frameSize":{"x":50,"y":36},"frameCount":1,"looping":true,"frameDelay":12,"version":"sJvwMWQouXjC875.0xqGXNWSghM7ryrg","loadedFromSource":true,"saved":true,"sourceSize":{"x":50,"y":36},"rootRelativePath":"assets/8f9de5ef-3705-4f62-bbc5-cb8367830a5b.png"},"88a4deb6-728c-4fd0-92b4-b324b57fe517":{"name":"high7","sourceUrl":null,"frameSize":{"x":50,"y":36},"frameCount":1,"looping":true,"frameDelay":12,"version":"nmWrclsCPEnxYiGhQW1WZCCwnh0WIK6V","loadedFromSource":true,"saved":true,"sourceSize":{"x":50,"y":36},"rootRelativePath":"assets/88a4deb6-728c-4fd0-92b4-b324b57fe517.png"},"e237296d-399f-4552-9460-b8a1cd937ba5":{"name":"high8","sourceUrl":null,"frameSize":{"x":50,"y":36},"frameCount":1,"looping":true,"frameDelay":12,"version":"genbu3ahabPTMZyqN6ODsmwNwKN4xLU.","loadedFromSource":true,"saved":true,"sourceSize":{"x":50,"y":36},"rootRelativePath":"assets/e237296d-399f-4552-9460-b8a1cd937ba5.png"},"e2bd9b27-b33f-43ef-ac1e-e2fe0fb95bca":{"name":"high9","sourceUrl":null,"frameSize":{"x":50,"y":36},"frameCount":1,"looping":true,"frameDelay":12,"version":"wnox5QXEhVcd5pyKVhfa5aDfI0ijVSo2","loadedFromSource":true,"saved":true,"sourceSize":{"x":50,"y":36},"rootRelativePath":"assets/e2bd9b27-b33f-43ef-ac1e-e2fe0fb95bca.png"},"d4f355e8-87d6-4a28-ab71-447c1195ef98":{"name":"high10","sourceUrl":null,"frameSize":{"x":50,"y":36},"frameCount":1,"looping":true,"frameDelay":12,"version":"F6TPTDg4OBIjE9F8oShV_yObDMgGG9Zu","loadedFromSource":true,"saved":true,"sourceSize":{"x":50,"y":36},"rootRelativePath":"assets/d4f355e8-87d6-4a28-ab71-447c1195ef98.png"},"f2f19110-e15a-495b-a72c-684373a4636c":{"name":"high11","sourceUrl":null,"frameSize":{"x":50,"y":36},"frameCount":1,"looping":true,"frameDelay":12,"version":"jzdjN4MVRXt2P1qcLpWdvcaz2yp3beQj","loadedFromSource":true,"saved":true,"sourceSize":{"x":50,"y":36},"rootRelativePath":"assets/f2f19110-e15a-495b-a72c-684373a4636c.png"},"e8f554bf-bf19-48a6-849f-88d4dd4b91a1":{"name":"full","sourceUrl":null,"frameSize":{"x":50,"y":36},"frameCount":1,"looping":true,"frameDelay":12,"version":"vp36KBZudp6dSy10YKra3CM_ybXXu7EN","loadedFromSource":true,"saved":true,"sourceSize":{"x":50,"y":36},"rootRelativePath":"assets/e8f554bf-bf19-48a6-849f-88d4dd4b91a1.png"},"fd0766a5-03c9-45d6-bc4c-d6cbbef3b6ef":{"name":"gameover","sourceUrl":null,"frameSize":{"x":225,"y":225},"frameCount":1,"looping":true,"frameDelay":12,"version":"C1N3W9hTVoLtDDGyoTX57VxOWzPA0vTA","loadedFromSource":true,"saved":true,"sourceSize":{"x":225,"y":225},"rootRelativePath":"assets/fd0766a5-03c9-45d6-bc4c-d6cbbef3b6ef.png"},"b01611f2-c22e-47a0-9e3d-a88c1b22fc5b":{"name":"rockgrass","sourceUrl":"assets/api/v1/animation-library/7T6HP.7czT_TTYSxP.W3qPNQywj5fdKg/category_obstacles/rockGrass.png","frameSize":{"x":108,"y":239},"frameCount":1,"looping":true,"frameDelay":2,"version":"7T6HP.7czT_TTYSxP.W3qPNQywj5fdKg","loadedFromSource":true,"saved":true,"sourceSize":{"x":108,"y":239},"rootRelativePath":"assets/api/v1/animation-library/7T6HP.7czT_TTYSxP.W3qPNQywj5fdKg/category_obstacles/rockGrass.png"},"97589118-4ede-44de-9dba-30b993e56fe9":{"name":"groundice","sourceUrl":"assets/api/v1/animation-library/sVdnknPyUtbIch1WfDh.TJJRWPPb53i4/category_obstacles/groundIce.png","frameSize":{"x":808,"y":71},"frameCount":1,"looping":true,"frameDelay":2,"version":"sVdnknPyUtbIch1WfDh.TJJRWPPb53i4","loadedFromSource":true,"saved":true,"sourceSize":{"x":808,"y":71},"rootRelativePath":"assets/api/v1/animation-library/sVdnknPyUtbIch1WfDh.TJJRWPPb53i4/category_obstacles/groundIce.png"},"022ffebb-2da2-417f-b308-4addc2fca896":{"name":"groundrock","sourceUrl":"assets/api/v1/animation-library/G1IEHSbhunaf5wpKLXnAEpDWYjI7bHro/category_obstacles/groundRock.png","frameSize":{"x":808,"y":71},"frameCount":1,"looping":true,"frameDelay":2,"version":"G1IEHSbhunaf5wpKLXnAEpDWYjI7bHro","loadedFromSource":true,"saved":true,"sourceSize":{"x":808,"y":71},"rootRelativePath":"assets/api/v1/animation-library/G1IEHSbhunaf5wpKLXnAEpDWYjI7bHro/category_obstacles/groundRock.png"},"c9d1fdc7-589f-48d0-a92b-14421025f68b":{"name":"groundsnow","sourceUrl":"assets/api/v1/animation-library/61Sn1Ftjg.EMrDQa.aDLh21NHyQY..Aw/category_obstacles/groundSnow.png","frameSize":{"x":808,"y":71},"frameCount":1,"looping":true,"frameDelay":2,"version":"61Sn1Ftjg.EMrDQa.aDLh21NHyQY..Aw","loadedFromSource":true,"saved":true,"sourceSize":{"x":808,"y":71},"rootRelativePath":"assets/api/v1/animation-library/61Sn1Ftjg.EMrDQa.aDLh21NHyQY..Aw/category_obstacles/groundSnow.png"},"66b661d0-c187-4546-81c7-3d502a8815c0":{"name":"rockice","sourceUrl":"assets/api/v1/animation-library/L_Oz3QQSZ8CgSrHZLIGCNEw4L91Oytj1/category_obstacles/rockIce.png","frameSize":{"x":108,"y":239},"frameCount":1,"looping":true,"frameDelay":2,"version":"L_Oz3QQSZ8CgSrHZLIGCNEw4L91Oytj1","loadedFromSource":true,"saved":true,"sourceSize":{"x":108,"y":239},"rootRelativePath":"assets/api/v1/animation-library/L_Oz3QQSZ8CgSrHZLIGCNEw4L91Oytj1/category_obstacles/rockIce.png"},"a5dbf601-b7cd-4062-9a18-5fbb46e91c0b":{"name":"rocksnow","sourceUrl":"assets/api/v1/animation-library/La9LDRO1pJpY3wGfkNOiQNioHvLhBbYb/category_obstacles/rockSnow.png","frameSize":{"x":108,"y":239},"frameCount":1,"looping":true,"frameDelay":2,"version":"La9LDRO1pJpY3wGfkNOiQNioHvLhBbYb","loadedFromSource":true,"saved":true,"sourceSize":{"x":108,"y":239},"rootRelativePath":"assets/api/v1/animation-library/La9LDRO1pJpY3wGfkNOiQNioHvLhBbYb/category_obstacles/rockSnow.png"},"0980b13e-c6e7-4ca3-8c74-a528a4b98185":{"name":"blackbackground","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"V1x3duGkStjQ7sCXpselsP1Y9ghCYPD8","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/0980b13e-c6e7-4ca3-8c74-a528a4b98185.png"},"40663659-3a93-4e34-915c-f0775f93c71a":{"name":"gold","sourceUrl":"assets/api/v1/animation-library/cqhKmzt4QrtNKhHyvpYQMy_djHWwOI_e/category_gameplay/flat_medal8.png","frameSize":{"x":41,"y":74},"frameCount":1,"looping":true,"frameDelay":2,"version":"cqhKmzt4QrtNKhHyvpYQMy_djHWwOI_e","loadedFromSource":true,"saved":true,"sourceSize":{"x":41,"y":74},"rootRelativePath":"assets/api/v1/animation-library/cqhKmzt4QrtNKhHyvpYQMy_djHWwOI_e/category_gameplay/flat_medal8.png"},"c2c19eba-9c80-4feb-a776-53b1002362f0":{"name":"silver","sourceUrl":"assets/api/v1/animation-library/3tIXTNgNAfX9KHv.hzCmwBgsOEYD8tcw/category_gameplay/flat_medal7.png","frameSize":{"x":41,"y":74},"frameCount":1,"looping":true,"frameDelay":2,"version":"3tIXTNgNAfX9KHv.hzCmwBgsOEYD8tcw","loadedFromSource":true,"saved":true,"sourceSize":{"x":41,"y":74},"rootRelativePath":"assets/api/v1/animation-library/3tIXTNgNAfX9KHv.hzCmwBgsOEYD8tcw/category_gameplay/flat_medal7.png"},"3781ed3f-c843-4084-a2cd-ee973c280186":{"name":"copper","sourceUrl":"assets/api/v1/animation-library/vrXajBFf8nQaxSU50EyMXgAzw2RYRkiA/category_gameplay/flat_medal2.png","frameSize":{"x":41,"y":74},"frameCount":1,"looping":true,"frameDelay":2,"version":"vrXajBFf8nQaxSU50EyMXgAzw2RYRkiA","loadedFromSource":true,"saved":true,"sourceSize":{"x":41,"y":74},"rootRelativePath":"assets/api/v1/animation-library/vrXajBFf8nQaxSU50EyMXgAzw2RYRkiA/category_gameplay/flat_medal2.png"},"a8aaa767-454e-4526-ab5d-d9496ffc778a":{"name":"logo","sourceUrl":null,"frameSize":{"x":119,"y":118},"frameCount":1,"looping":true,"frameDelay":12,"version":"ncX9q54dzOeAALMECv1sdH.HjWzAhvN9","loadedFromSource":true,"saved":true,"sourceSize":{"x":119,"y":118},"rootRelativePath":"assets/a8aaa767-454e-4526-ab5d-d9496ffc778a.png"},"46b1cb56-ba08-4a74-9896-ba322d82b6fe":{"name":"finishline","sourceUrl":null,"frameSize":{"x":100,"y":12},"frameCount":1,"looping":true,"frameDelay":12,"version":"WgnKHaLf4PJe8agc5Um_cd6ddaa3w9Zj","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":12},"rootRelativePath":"assets/46b1cb56-ba08-4a74-9896-ba322d82b6fe.png"},"f84252f0-fea6-48a5-ad8d-7a1e6fe8d373":{"name":"shell1","sourceUrl":null,"frameSize":{"x":242,"y":208},"frameCount":1,"looping":true,"frameDelay":12,"version":"35wSPcVBwTq5gRD6BvzOu3MXxUuMlS0a","loadedFromSource":true,"saved":true,"sourceSize":{"x":242,"y":208},"rootRelativePath":"assets/f84252f0-fea6-48a5-ad8d-7a1e6fe8d373.png"},"356d4514-37c6-48f8-9b73-c61ea025fbec":{"name":"shell2","sourceUrl":null,"frameSize":{"x":275,"y":183},"frameCount":1,"looping":true,"frameDelay":12,"version":"IOjirNSLPWuaqIqdObqda3KPLJiYQzfh","loadedFromSource":true,"saved":true,"sourceSize":{"x":275,"y":183},"rootRelativePath":"assets/356d4514-37c6-48f8-9b73-c61ea025fbec.png"},"80ad3ecc-8556-4554-b5bf-cad095c9683a":{"name":"bomb","sourceUrl":null,"frameSize":{"x":225,"y":225},"frameCount":1,"looping":true,"frameDelay":12,"version":"WaRdv.Hax7M6pqWaxJhtHz0DV1y8R.8g","loadedFromSource":true,"saved":true,"sourceSize":{"x":225,"y":225},"rootRelativePath":"assets/80ad3ecc-8556-4554-b5bf-cad095c9683a.png"},"2388cac9-2503-46b7-8bd9-fa84761e8cd4":{"name":"sign1","sourceUrl":null,"frameSize":{"x":216,"y":233},"frameCount":1,"looping":true,"frameDelay":12,"version":"QhObsSanh4_i4Li4EKsh4nEV6xm.NcLR","loadedFromSource":true,"saved":true,"sourceSize":{"x":216,"y":233},"rootRelativePath":"assets/2388cac9-2503-46b7-8bd9-fa84761e8cd4.png"},"f5e8bd44-dbad-4fef-bd49-f318512c33cd":{"name":"truck","sourceUrl":"assets/api/v1/animation-library/gamelab/FW8VwzdEyxYf2EGLtcOBDFBpG_3jC91./category_vehicles/playerShip2_blue.png","frameSize":{"x":112,"y":75},"frameCount":1,"looping":true,"frameDelay":2,"version":"FW8VwzdEyxYf2EGLtcOBDFBpG_3jC91.","loadedFromSource":true,"saved":true,"sourceSize":{"x":112,"y":75},"rootRelativePath":"assets/api/v1/animation-library/gamelab/FW8VwzdEyxYf2EGLtcOBDFBpG_3jC91./category_vehicles/playerShip2_blue.png"},"10d5166e-aa72-4bd9-82ad-36acdfa66b7b":{"name":" truckcrash1","sourceUrl":"assets/api/v1/animation-library/gamelab/FW8VwzdEyxYf2EGLtcOBDFBpG_3jC91./category_vehicles/playerShip2_blue.png","frameSize":{"x":112,"y":75},"frameCount":1,"looping":true,"frameDelay":2,"version":"FW8VwzdEyxYf2EGLtcOBDFBpG_3jC91.","loadedFromSource":true,"saved":true,"sourceSize":{"x":112,"y":75},"rootRelativePath":"assets/api/v1/animation-library/gamelab/FW8VwzdEyxYf2EGLtcOBDFBpG_3jC91./category_vehicles/playerShip2_blue.png"},"7f780ccc-66d0-46f4-90ca-1c2618e71376":{"name":"new car","sourceUrl":"assets/api/v1/animation-library/gamelab/3SIijXEfiW9lf_IlrR_jixOvY.X6yVOr/category_vehicles/motorcycle.png","frameSize":{"x":71,"y":131},"frameCount":1,"looping":true,"frameDelay":2,"version":"3SIijXEfiW9lf_IlrR_jixOvY.X6yVOr","loadedFromSource":true,"saved":true,"sourceSize":{"x":71,"y":131},"rootRelativePath":"assets/api/v1/animation-library/gamelab/3SIijXEfiW9lf_IlrR_jixOvY.X6yVOr/category_vehicles/motorcycle.png"},"68eb9ed5-0949-4f73-b4bf-896a17a21f1b":{"name":"new carcrash","sourceUrl":null,"frameSize":{"x":71,"y":131},"frameCount":1,"looping":true,"frameDelay":12,"version":"6uohmf75wePQrw99Nk6X4iWHyoLA0fxN","loadedFromSource":true,"saved":true,"sourceSize":{"x":71,"y":131},"rootRelativePath":"assets/68eb9ed5-0949-4f73-b4bf-896a17a21f1b.png"},"f604c740-e0d6-4f1a-9796-67655635eacb":{"name":" blue","sourceUrl":"assets/api/v1/animation-library/gamelab/zCat2wSxi.yio2rKDxvF_eBKkhmF79Lu/category_vehicles/enemyBlack3.png","frameSize":{"x":103,"y":84},"frameCount":1,"looping":true,"frameDelay":2,"version":"zCat2wSxi.yio2rKDxvF_eBKkhmF79Lu","loadedFromSource":true,"saved":true,"sourceSize":{"x":103,"y":84},"rootRelativePath":"assets/api/v1/animation-library/gamelab/zCat2wSxi.yio2rKDxvF_eBKkhmF79Lu/category_vehicles/enemyBlack3.png"},"5f337ac4-92ae-43c8-b8f1-1ac77a09bfb2":{"name":" bluecrash1","sourceUrl":null,"frameSize":{"x":103,"y":84},"frameCount":1,"looping":true,"frameDelay":12,"version":"wX2hH75JTONlZ5QcsfrYB_HsEih4wEOi","loadedFromSource":true,"saved":true,"sourceSize":{"x":103,"y":84},"rootRelativePath":"assets/5f337ac4-92ae-43c8-b8f1-1ac77a09bfb2.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

playSound("assets/category_music/clear_evidence_loop1.mp3",false); 
//backgrounds
var grass = createSprite(200, 200);
grass.setAnimation("grass");
grass.scale=4;

//road
var road = createSprite(200, 200);
road.setAnimation("road1");
road.scale = 2;
road.rotation = 90;

//obstacles1
var obstacle1 = createSprite(randomNumber(100,300), randomNumber(-2000,-3000));
obstacle1.setAnimation("groundrock");
obstacle1.scale = 0.1;
//obstacles2
var obstacle2 = createSprite(randomNumber(50,350), randomNumber(-3000,-4000));
obstacle2.setAnimation("rockgrass");
obstacle2.scale = 0.3;

//start
var start = createSprite(200,130);
start.setAnimation("finishline");
start.scale = 3;

//finishline
var finishline = createSprite(200,-60);
finishline.setAnimation("finishline");
finishline.scale = 3;

//grass1
var grass1 = createSprite(390, 50);
grass1.setAnimation("grass1");
grass1.scale = 0.6; 

//grass2
var grass2 = createSprite(392, 150);
grass2.setAnimation("grass2");
grass2.scale = 0.6;

//grass3
var grass3 = createSprite(383,250);
grass3.setAnimation("grass3");
grass3.scale = 0.6;

//grass4
var grass4 = createSprite(388,350);
grass4.setAnimation("seed");
grass4.scale = 0.4;

//grass5
var grass5 = createSprite(20, 200);
grass5.setAnimation("grass1");
grass5.scale= 0.6;

//grass6
var grass6 = createSprite(18, 20);
grass6.setAnimation("grass2");
grass6.scale= 0.6;

//grass7
var grass7 = createSprite(18, 160);
grass7.setAnimation("seed");
grass7.scale= 0.6;

//grass8
var grass8 = createSprite(17,300);
grass8.setAnimation("grass3");
grass8.scale = 0.6;

//blue
var blue = createSprite(250, 199);
blue.setAnimation(" blue");
blue.scale = 0.8;

//green
var green = createSprite(330, 200);
green.setAnimation("green");
green.scale = 0.8;

//yellow
var yellow = createSprite(330, 330);
yellow.setAnimation("yellow");
yellow.scale= 0.8;

//coin
var coin = createSprite(randomNumber(40,360), randomNumber(0,160));
coin.setAnimation("coin");
coin.scale= 0.6;

//jetpack
var jetpack = createSprite(randomNumber(60,340), randomNumber(-300,-400));
jetpack.setAnimation("jetpack");
jetpack.scale = 0.3;

//graphic
var graphic = createSprite(30, 100);
graphic.setAnimation("empty1");

//black1
var black1 = createSprite(155, -3000);
black1.setAnimation("black");
black1.scale = 0.8;
black1.rotation = 180;

//black2
var black2 = createSprite(250, 2000);
black2.setAnimation("new car");
black2.scale = 0.8;

//truck
var truck = createSprite(75, -800);
truck.setAnimation("truck");
truck.rotation = 180;
truck.scale = 0.8;

//diamond1
var diamond1 = createSprite(330, -3000);
diamond1.setAnimation("diamond");
diamond1.scale = 0.8;
//diamond2
var diamond2 = createSprite(250, -3000);
diamond2.setAnimation("diamond");
diamond2.scale = 0.8;
//diamond3
var diamond3 = createSprite(155, -3000);
diamond3.setAnimation("diamond");
diamond3.scale = 0.8;

var superspeed = createSprite(200,200);
superspeed.setAnimation("super speed");
superspeed.visible = 0;
superspeed.scale = 0.6;

//I'm your superpowers
var Iamyoursuperpowers = createSprite(330, 80);
Iamyoursuperpowers.setAnimation("I'm your superpowers");
Iamyoursuperpowers.scale = 0.3;
Iamyoursuperpowers.visible = 0;

//hit1
var perfecthit1 = createSprite(200,40);
perfecthit1.setAnimation("perfect hit 1");
perfecthit1.scale = 0.5;
perfecthit1.visible = 0;

//hit2
var perfecthit2 = createSprite(200,40);
perfecthit2.setAnimation("perfect hit 2");
perfecthit2.scale = 0.5;
perfecthit2.visible = 0;

//shell1
var shell1 = createSprite(200, 200);
shell1.setAnimation("shell1");
shell1.scale = 0.2;
shell1.visible = 0;

//shell2
var shell2 = createSprite(200, 200);
shell2.setAnimation("shell2");
shell2.scale = 0.2;
shell2.visible = 0;

//bomb
var bomb = createSprite(200, 200);
bomb.setAnimation("bomb");
bomb.scale = 0.2;
bomb.visible = 0;

//logo
var logo = createSprite(200, 200);
logo.setAnimation("logo");
logo.scale = 0.13;
logo.rotation = 180;
logo.visible = 0;

//light
var light = createSprite(200,30);
light.setAnimation("lightred");
light.rotation = -90;
light.scale = 0.7;
light.visible = 0;

//sign
var sign1 = createSprite(200, 40);
sign1.setAnimation("sign1");
sign1.scale = 0.6;
sign1.visible = 0;

//choose
var blackbackground = createSprite(200, 200);
blackbackground.setAnimation("blackbackground");
blackbackground.scale = 4;

var chooseblue = createSprite(50, 300);
chooseblue.setAnimation(" blue");
chooseblue.scale = 0.7;

var choosegreen = createSprite(250, 300);
choosegreen.setAnimation("green");
choosegreen.scale = 0.7;

var chooseblack = createSprite(150,300);
chooseblack.setAnimation("black");
chooseblack.scale = 0.7;

var choosetruck = createSprite(350,300);
choosetruck.setAnimation("truck");
choosetruck.scale = 0.7;

var choosenew = createSprite(160,220);
choosenew.setAnimation("new car");
choosenew.scale = 0.7;
choosenew.rotation = -90;

//model
var model = createSprite(305,90);
model.setAnimation("high2");


//meadel
var meadel = createSprite(200,200);
meadel.setAnimation("gold");
meadel.visible = 0;

//varibles
var everythingaboutblue = 0;
var live = 3;
var score = 0;
var supercharge = 0;
var jet = 0;
var black1out = 0;
var black2out = 0;
var greenout = 0;
var yellowout = 0;
var truckout = 0;
var backgroundtext = 1;
var backgroundtext2 = 0;
var startnow = 0;
var place = 1;
var finish = 0;
var greenhit = 0;
var snowice = 0;
var counter1 = 0;
var counter2 = 0;
var counter3 = 0;
var counter4 = 0;
var counter5 = 0;
var superpower = 0;
var whatdiamondslooklike = 0;
var howlong = 500;
var howlongitwilltake = 20;
var thisiscool = 0;
var shellhit1 = 0;
var shellhit2 = 0;
var ifshellhit = 0;
var bombhit1 = 0;
var last = 0;
var speed = 0;
var speedfast = 0;

//slowdown
function slowdown() {
  green.velocityY = -4;
  grass1.velocityY = grass1.velocityY -4;
  grass2.velocityY = grass2.velocityY -4;
  grass3.velocityY = grass3.velocityY -4;
  grass4.velocityY = grass4.velocityY -4;
  grass5.velocityY = grass5.velocityY -4;
  grass6.velocityY = grass6.velocityY -4;
  grass7.velocityY = grass7.velocityY -4;
  grass8.velocityY = grass8.velocityY -4;
  coin.velocityY = coin.velocityY -4;
  jetpack.velocityY = jetpack.velocityY -4;
  black1.velocityY = black1.velocityY +4;
  truck.velocityY = truck.velocityY +4;
  black2.velocityY = -4;
  yellow.velocityY = -4;
}

//diamonds1
function diamonds1() {
  diamond1.x = 155;
  diamond1.y = -3000;
  diamond2.x = 250;
  diamond2.y = -3000;
  diamond3.x = 330;
  diamond3.y = -3000;
}

//diamonds2
function diamonds2() {
  diamond1.x = 75;
  diamond1.y = -3000;
  diamond2.x = 250;
  diamond2.y = -3000;
  diamond3.x = 330;
  diamond3.y = -3000;
}

//diamonds3
                                       function diamonds3() {
  diamond1.x = 155;
  diamond1.y = -3000;
  diamond2.x = 75;
  diamond2.y = -3000;
  diamond3.x = 330;
  diamond3.y = -3000;
}
  
//diamonds4
function diamonds4() {
  diamond1.x = 155;
  diamond1.y = -3000;
  diamond2.x = 250;
  diamond2.y = -3000;
  diamond3.x = 75;
  diamond3.y = -3000;
}


//slowdown2
function slowdown2() {
  green.velocityY = -3;
  grass1.velocityY = grass1.velocityY -3;
  grass2.velocityY = grass2.velocityY -3;
  grass3.velocityY = grass3.velocityY -3;
  grass4.velocityY = grass4.velocityY -3;               
  grass5.velocityY = grass5.velocityY -3;
  grass6.velocityY = grass6.velocityY -3;
  grass7.velocityY = grass7.velocityY -3;
  grass8.velocityY = grass8.velocityY -3;
  coin.velocityY = coin.velocityY -3;
  jetpack.velocityY = jetpack.velocityY -3;
  black1.velocityY = black1.velocityY -3;
  black2.velocityY = black2.velocityY+3;
  yellow.velocityY = yellow.velocityY -3;
}

//faster
function faster() {
  grass1.velocityY = grass1.velocityY +1;
  grass2.velocityY = grass2.velocityY +1;
  grass3.velocityY = grass3.velocityY +1;
  grass4.velocityY = grass4.velocityY +1;
  grass5.velocityY = grass5.velocityY +1;
  grass6.velocityY = grass6.velocityY +1;
  grass7.velocityY = grass7.velocityY +1;
  grass8.velocityY = grass8.velocityY +1;
  coin.velocityY = coin.velocityY +1;
  jetpack.velocityY = jetpack.velocityY +1;
  obstacle2.velocityY = obstacle2.velocityY +1;
  obstacle1.velocityY = obstacle1 +1;
  diamond3.velocityY = diamond3.velocityY +2;
  diamond2.velocityY = diamond2.velocityY +2;
  diamond1.velocityY = diamond1.velocityY +2;
  if ((blue.isTouching(jetpack)) && (supercharge < 10)){
    jetpack.y = randomNumber(-300,-400);
    jetpack.x = randomNumber(60,340);
    supercharge = supercharge +2;
    jet = jet + 6;
  }
}

//faster2
function faster2() {
  grass1.velocityY = grass1.velocityY +2;
  grass2.velocityY = grass2.velocityY +2;
  grass3.velocityY = grass3.velocityY +2;
  grass4.velocityY = grass4.velocityY +2;
  grass5.velocityY = grass5.velocityY +2;
  grass6.velocityY = grass6.velocityY +2;
  grass7.velocityY = grass7.velocityY +2;
  grass8.velocityY = grass8.velocityY +2;
  coin.velocityY = coin.velocityY +2;
  jetpack.velocityY = jetpack.velocityY +2;
  green.velocityY = green.velocityY +2;
  yellow.velocityY = yellow.velocityY +2;
  obstacle2.velocityY = obstacle2.velocityY +2;
  obstacle1.velocityY = obstacle1 +2;
  diamond3.velocityY = diamond3.velocityY +2;
  diamond2.velocityY = diamond2.velocityY +2;
  diamond1.velocityY = diamond1.velocityY +2;
}

//loop
function draw() {
  background("white");
  if ((mousePressedOver(chooseblue) && everythingaboutblue <= 0)){
    playSound("assets/category_app/app_button_5.mp3", false);
    blackbackground.visible = 0;
    chooseblue.destroy();
    choosegreen.destroy();
    chooseblack.destroy();
    choosetruck.destroy();
    choosenew.destroy();
    startnow = 1;
    backgroundtext = 0;
    model.destroy();
    counter3 =1;
  }
  if ((mousePressedOver(choosegreen) && everythingaboutblue <= 0)){
    playSound("assets/category_app/app_button_5.mp3", false);
    blue.setAnimation("green");
    green.setAnimation("blue");
    blackbackground.visible = 0;
    chooseblue.destroy();
    choosegreen.destroy();
    chooseblack.destroy();
    choosetruck.destroy();
    choosenew.destroy();
    startnow = 1;
    backgroundtext = 0;
    model.destroy();
    counter2 =1;
  }
  
  if ((mousePressedOver(chooseblack) && everythingaboutblue <= 0)){
    playSound("assets/category_app/app_button_5.mp3", false);
    blue.setAnimation("black");
    counter1 = 1;
    blackbackground.visible = 0;
    chooseblue.destroy();
    choosegreen.destroy();
    chooseblack.destroy();
    choosetruck.destroy();
    choosenew.destroy();
    startnow = 1;
    backgroundtext = 0;
    model.destroy();
  }
  if ((mousePressedOver(choosetruck) && everythingaboutblue <= 0)){
    playSound("assets/category_app/app_button_5.mp3", false);
    blue.setAnimation("truck");
    counter4 = 1;
    blackbackground.visible = 0;
    chooseblue.destroy();
    choosegreen.destroy();
    chooseblack.destroy();
    choosetruck.destroy();
    choosenew.destroy();
    startnow = 1;
    backgroundtext = 0;
    model.destroy();
  }
  if ((mousePressedOver(choosenew) && everythingaboutblue <= 0)){
    playSound("assets/category_app/app_button_5.mp3", false);
    blue.setAnimation("new car");
    counter5 = 1;
    blackbackground.visible = 0;
    chooseblue.destroy();
    choosegreen.destroy();
    chooseblack.destroy();
    choosetruck.destroy();
    choosenew.destroy();
    startnow = 1;
    backgroundtext = 0;
    model.destroy();
  }
  if (startnow >= 1){
    everythingaboutblue = everythingaboutblue +1;
    thisiscool = 1;
  }
  //hit other cars
  if (score >= 20){
    //green back
    if ((blue.isTouching(green)) && (green.y < 150) &&(blue.x < green.x)){
      playSound("assets/category_digital/win.mp3", false);
      score = score - 20;
      green.setAnimation("greencrash1");
      green.velocityY = +7;
      green.rotationSpeed = 3;
      green.rotation = +30;
      green.velocityX = 3;
    }
    if ((blue.isTouching(green)) && (green.y < 150) &&(blue.x >= green.x)){
      playSound("assets/category_digital/win.mp3", false);
      score = score - 20;
      green.setAnimation("greencrash1");
      green.velocityY = +7;
      green.rotationSpeed = 3;
      green.rotation = -30;
      green.velocityX = -3;
    }
    //green front
    if ((blue.isTouching(green)) && (green.y >= 260) &&(blue.x < green.x)){
      playSound("assets/category_digital/win.mp3", false);
      score = score - 20;
      green.setAnimation("greencrash1");
      green.rotationSpeed = 3;
      green.rotation = +360;
      green.velocityY = +7;
      green.velocityX = 3;
    }
    if ((blue.isTouching(green)) && (green.y >= 260) &&(blue.x >= green.x)){
      playSound("assets/category_digital/win.mp3", false);
      score = score - 20;
      green.setAnimation("greencrash1");
      green.rotationSpeed = 3;
      green.rotation = -360;
      green.velocityY = +7;
      green.velocityX = -3;
    }
    //green middle
    if ((blue.isTouching(green)) && (green.y < 260) && (green.y >= 150) &&(blue.x < green.x)){
      playSound("assets/category_digital/win.mp3", false);
      score = score - 20;
      green.setAnimation("greencrash1");
      green.velocityY = +7;
      green.velocityX = +5;
    }
    if ((blue.isTouching(green)) && (green.y < 260) && (green.y >= 150) &&(blue.x >= green.x)){
      playSound("assets/category_digital/win.mp3", false);
      score = score - 20;
      green.setAnimation("greencrash1");
      green.velocityY = +7;
      green.velocityX = -5;
    }
    //yellow back
    if ((blue.isTouching(yellow)) && (yellow.y < 150) && (blue.x >= yellow.x)){
      playSound("assets/category_digital/win.mp3", false);
      score = score - 20;
      yellow.setAnimation("yellowcrash1");
      yellow.velocityY = +7;
      yellow.rotationSpeed = 3;
      yellow.rotation = +30;
      yellow.velocityX = -3;
    }

    if ((blue.isTouching(yellow)) && (yellow.y < 150) && (blue.x < yellow.x)){
      playSound("assets/category_digital/win.mp3", false);
      score = score - 20;
      yellow.setAnimation("yellowcrash1");
      yellow.velocityY = +7;
      yellow.rotationSpeed = 3;
      yellow.rotation = -30;
      yellow.velocityX = 3;
    }
    //yellow front
    if ((blue.isTouching(yellow)) && (yellow.y >= 260) && blue.x < yellow.x){
      playSound("assets/category_digital/win.mp3", false);
      score = score - 20;
      yellow.setAnimation("yellowcrash1");
      yellow.rotationSpeed = 3;
      yellow.rotation = 360;
      yellow.velocityY = +7;
      yellow.velocityX = 3;
    }
    if ((blue.isTouching(yellow)) && (yellow.y >= 260) && blue.x >= yellow.x){
      playSound("assets/category_digital/win.mp3", false);
      score = score - 20;
      yellow.setAnimation("yellowcrash1");
      yellow.rotationSpeed = 3;
      yellow.rotation = -360;
      yellow.velocityY = +7;
      yellow.velocityX = -3;
    }
    //yellow middle
    if ((blue.isTouching(yellow)) && (yellow.y < 260) && (yellow.y >= 150) && (blue.x < yellow.x)){
      playSound("assets/category_digital/win.mp3", false);
      score = score - 20;
      yellow.setAnimation("yellowcrash1");
      yellow.velocityY = +7;
      yellow.velocityX = 5;
      
    }
    if ((blue.isTouching(yellow)) && (yellow.y < 260) && (yellow.y >= 150) && (blue.x >= yellow.x)){
      playSound("assets/category_digital/win.mp3", false);
      score = score - 20;
      yellow.setAnimation("yellowcrash1");
      yellow.velocityY = +7;
      yellow.velocityX = -5;
    }
    
    //black2 back
    if ((blue.isTouching(black2)) && (black2.y < 150) && blue.x < black2.x ){
      playSound("assets/category_digital/win.mp3", false);
      score = score - 20;
      black2.setAnimation("new carcrash");
      black2.velocityX = 4;
      black2.rotationSpeed = 3;
      black2.rotation = -30;
      black2.velocityY = +7;
    }
    if ((blue.isTouching(black2)) && (black2.y < 150) && blue.x >= black2.x ){
      playSound("assets/category_digital/win.mp3", false);
      score = score - 20;
      black2.setAnimation("new carcrash");
      black2.velocityX = -4;
      black2.rotationSpeed = 3;
      black2.rotation = +30;
      black2.velocityY = +7;
    }
    //black2 front
    if ((blue.isTouching(black2)) && (black2.y >= 260) && blue.x < black2.x ){
      playSound("assets/category_digital/win.mp3", false);
      score = score - 20;
      black2.setAnimation("new carcrash");
      black2.rotationSpeed = 3;
      black2.rotation = +30;
      black2.velocityY = +7;
      black2.velocityX = 7;
    }
    if ((blue.isTouching(black2)) && (black2.y >= 260) && blue.x >= black2.x ){
      playSound("assets/category_digital/win.mp3", false);
      score = score - 20;
      black2.setAnimation("new carcrash");
      black2.rotationSpeed = 3;
      black2.rotation = -30;
      black2.velocityY = +7;
      black2.velocityX = -7;
    }
    // black2 middle
    if ((blue.isTouching(black2)) && (black2.y < 260) && (black2.y >= 150) && blue.x < black2.x){
      playSound("assets/category_digital/win.mp3", false);
      score = score - 20;
      black2.setAnimation("new carcrash");
      black2.velocityY = +7;
      black2.velocityX = 3;
    }
    if ((blue.isTouching(black2)) && (black2.y < 260) && (black2.y >= 150) && blue.x >= black2.x){
      playSound("assets/category_digital/win.mp3", false);
      score = score - 10;
      black2.setAnimation("new carcrash");
      black2.velocityY = +7;
      black2.velocityX = -3;
    }
    //black1 front
    if ((blue.isTouching(black1)) && (black1.y < 150) && (blue.x >= black1.x)){
      playSound("assets/category_digital/win.mp3", false);
      score = score - 10;
      black1.setAnimation("blackcrash1");
      black1.rotation = 180;
      black1.velocityY = +3;
      black1.rotationSpeed = 3;
      black1.rotation = +30;
      black1.velocityX = -3;
    }

    if ((blue.isTouching(black1)) && (black1.y < 150) && (blue.x < black1.x)){
      playSound("assets/category_digital/win.mp3", false);
      score = score - 10;
      black1.setAnimation("blackcrash1");
      black1.rotation = 180;
      black1.velocityY = +3;
      black1.rotationSpeed = 3;
      black1.rotation = -30;
      black1.velocityX = 3;
    }
    //black1 back
    if ((blue.isTouching(black1)) && (black1.y >= 260) && blue.x < black1.x){
      playSound("assets/category_digital/win.mp3", false);
      score = score - 10;
      black1.setAnimation("blackcrash1");
      black1.rotation = 180;
      black1.rotationSpeed = 3;
      black1.rotation = 360;
      black1.velocityY = +7;
      black1.velocityX = 3;
    }
    if ((blue.isTouching(black1)) && (black1.y >= 260) && blue.x >= black1.x){
      playSound("assets/category_digital/win.mp3", false);
      score = score - 10;
      black1.setAnimation("blackcrash1");
      black1.rotation = 180;
      black1.rotationSpeed = 3;
      black1.rotation = -360;
      black1.velocityY = +7;
      black1.velocityX = -3;
    }
    //black1 middle
    if ((blue.isTouching(black1)) && (black1.y < 260) && (black1.y >= 150) && (blue.x < black1.x)){
      playSound("assets/category_digital/win.mp3", false);
      score = score - 10;
      black1.setAnimation("blackcrash1");
      black1.rotation = 180;
      black1.velocityY = +7;
      black1.velocityX = 5;
    }
    //truck front
    if ((blue.isTouching(truck)) && (truck.y < 150) && (blue.x >= truck.x)){
      playSound("assets/category_digital/win.mp3", false);
      score = score - 10;
      truck.setAnimation(" truckcrash1");
      truck.rotation = 180;
      truck.velocityY = +3;
      truck.rotationSpeed = 3;
      truck.rotation = +30;
      truck.velocityX = -3;
      if (counter1 == 1 || counter2 == 1 || counter3 == 1){
        live = 1;
      }
      
    }

    if ((blue.isTouching(truck)) && (truck.y < 150) && (blue.x < truck.x)){
      playSound("assets/category_digital/win.mp3", false);
      score = score - 10;
      truck.setAnimation("truckcrash1");
      truck.rotation = 180;
      truck.velocityY = +3;
      truck.rotationSpeed = 3;
      truck.rotation = -30;
      truck.velocityX = 3;
      if (counter1 == 1 || counter2 == 1 || counter3 == 1){
        live = 1;
      }
    }
    //truck back
    if ((blue.isTouching(truck)) && (truck.y >= 260) && blue.x < truck.x){
      playSound("assets/category_digital/win.mp3", false);
      score = score - 10;
      truck.setAnimation("truckcrash1");
      truck.rotation = 180;
      truck.rotationSpeed = 3;
      truck.rotation = 360;
      truck.velocityY = +7;
      truck.velocityX = 3;
      if (counter1 == 1 || counter2 == 1 || counter3 == 1){
        live = 1;
      }
    }
    if ((blue.isTouching(truck)) && (truck.y >= 260) && blue.x >= truck.x){
      playSound("assets/category_digital/win.mp3", false);
      score = score - 10;
      truck.setAnimation("truckcrash1");
      truck.rotation = 180;
      truck.rotationSpeed = 3;
      truck.rotation = -360;
      truck.velocityY = +7;
      truck.velocityX = -3;
      if (counter1 == 1 || counter2 == 1 || counter3 == 1){
        live = 1;
      }
    }
    //truck middle
    if ((blue.isTouching(truck)) && (truck.y < 260) && (truck.y >= 150) && (blue.x < truck.x)){
      playSound("assets/category_digital/win.mp3", false);
      score = score - 10;
      truck.setAnimation("truckcrash1");
      truck.rotation = 180;
      truck.velocityY = +7;
      truck.velocityX = 5;
      if (counter1 == 1 || counter2 == 1 || counter3 == 1){
        live = 1;
      }
    }
    if ((blue.isTouching(truck)) && (truck.y < 260) && (truck.y >= 150) && (blue.x >= truck.x)){
      playSound("assets/category_digital/win.mp3", false);
      score = score - 10;
      truck.setAnimation("truckcrash1");
      truck.rotation = 180;
      truck.velocityY = +7;
      truck.velocityX = -5;
      if (counter1 == 1 || counter2 == 1 || counter3 == 1){
        live = 1;
      }
    }
  } else {
    
    //green back
    if ((blue.isTouching(green)) && (green.y > 150) && (blue.x < green.x)){
      playSound("assets/category_tap/puzzle_game_organic_wood_block_tone_tap_2.mp3", false);
      blue.x = blue.x -40;
      green.y = green.y - 15;
    }
    if ((blue.isTouching(green)) && (green.y > 150) && (blue.x >= green.x)){
      playSound("assets/category_tap/puzzle_game_organic_wood_block_tone_tap_2.mp3", false);
      blue.x = blue.x +40;
      green.y = green.y - 15;
    }
    //green front
    if ((blue.isTouching(green)) && (green.y >= 260) && (blue.x < green.x)){
      playSound("assets/category_tap/puzzle_game_organic_wood_block_tone_tap_2.mp3", false);
      blue.x = blue.x -40;
    }
    if ((blue.isTouching(green)) && (green.y >= 260) && (blue.x >= green.x)){
      playSound("assets/category_tap/puzzle_game_organic_wood_block_tone_tap_2.mp3", false);
      blue.x = blue.x +40;
    }
    //green middle
    if ((blue.isTouching(green)) && (green.y < 260) && (green.y >= 150) && (blue.x < green.x)){
      playSound("assets/category_tap/puzzle_game_organic_wood_block_tone_tap_2.mp3", false);
      blue.x = blue.x -40;
      green.y = green.y +60;
    }
    if ((blue.isTouching(green)) && (green.y < 260) && (green.y >= 150) && (blue.x >= green.x)){
      playSound("assets/category_tap/puzzle_game_organic_wood_block_tone_tap_2.mp3", false);
      blue.x = blue.x +40;
      green.y = green.y +60;
    }
    
    //yellow back
    if ((blue.isTouching(yellow)) && (yellow.y > 150) && (blue.x < yellow.x)){
      playSound("assets/category_tap/puzzle_game_organic_wood_block_tone_tap_2.mp3", false);
      blue.x = blue.x -40;
      yellow.y = yellow.y - 15;
    }
    if ((blue.isTouching(yellow)) && (yellow.y > 150) && (blue.x >= yellow.x)){
      playSound("assets/category_tap/puzzle_game_organic_wood_block_tone_tap_2.mp3", false);
      blue.x = blue.x +40;
      yellow.y = yellow.y - 15;
    }
    //yellow front
    if ((blue.isTouching(yellow)) && (yellow.y >= 260) &&(blue.x < yellow.x)){
      playSound("assets/category_tap/puzzle_game_organic_wood_block_tone_tap_2.mp3", false);
      blue.x = blue.x -40;
      yellow.y = yellow.y + 15;
    }
    if ((blue.isTouching(yellow)) && (yellow.y >= 260) &&(blue.x >= yellow.x)){
      playSound("assets/category_tap/puzzle_game_organic_wood_block_tone_tap_2.mp3", false);
      blue.x = blue.x +40;
      yellow.y = yellow.y + 15;
    }
    //yellow middle
    if ((blue.isTouching(yellow)) && (yellow.y < 260) && (yellow.y >= 150) && (blue.x < yellow.x)){
      playSound("assets/category_tap/puzzle_game_organic_wood_block_tone_tap_2.mp3", false);
      blue.x = blue.x -40;
      yellow.x = yellow.x +20;
    }
    if ((blue.isTouching(yellow)) && (yellow.y < 260) && (yellow.y >= 150) && (blue.x >= yellow.x)){
      playSound("assets/category_tap/puzzle_game_organic_wood_block_tone_tap_2.mp3", false);
      blue.x = blue.x +40;
      yellow.x = yellow.x -20;
    }
    //black2 back
    if ((blue.isTouching(black2)) && (black2.y > 150) && blue.x < black2.x){
      playSound("assets/category_tap/puzzle_game_organic_wood_block_tone_tap_2.mp3", false);
      black2.y = black2.y + 15;
    }
    if ((blue.isTouching(black2)) && (black2.y > 150) && blue.x >= black2.x){
      playSound("assets/category_tap/puzzle_game_organic_wood_block_tone_tap_2.mp3", false);
      black2.y = black2.y - 15;
    }
    //black2 front
    if ((blue.isTouching(black2)) && (black2.y >= 260) && blue.x < black2.x){
      playSound("assets/category_tap/puzzle_game_organic_wood_block_tone_tap_2.mp3", false);
      blue.x = blue.x -40;
    }
    if ((blue.isTouching(black2)) && (black2.y >= 260) && blue.x >= black2.x){
      playSound("assets/category_tap/puzzle_game_organic_wood_block_tone_tap_2.mp3", false);
      blue.x = blue.x +40;
    }
    //black2 middle
    if ((blue.isTouching(black2)) && (black2.y < 260) && (black2.y >= 150) && blue.x < black2.x){
      playSound("assets/category_tap/puzzle_game_organic_wood_block_tone_tap_2.mp3", false);
      blue.x = blue.x -40;
      black2.y = black2.y +60; 
    }
    if ((blue.isTouching(black2)) && (black2.y < 260) && (black2.y >= 150) && blue.x >= black2.x){
      playSound("assets/category_tap/puzzle_game_organic_wood_block_tone_tap_2.mp3", false);
      blue.x = blue.x +40;
      black2.y = black2.y -60; 
    }
    //black1 front
    if ((blue.isTouching(black1)) && (black1.y > 150) && blue.x < black1.x){
      playSound("assets/category_tap/puzzle_game_organic_wood_block_tone_tap_2.mp3", false);
      blue.x = blue.x -40;
      black1.y = black1.y + 15;
    }
    if ((blue.isTouching(black1)) && (black1.y > 150) && blue.x >= black1.x){
      playSound("assets/category_tap/puzzle_game_organic_wood_block_tone_tap_2.mp3", false);
      blue.x = blue.x +40;
      black1.y = black1.y - 15;
    }
    //black1 back
    if ((blue.isTouching(black1)) && (black1.y >= 260) && blue.x < black1.x){
      playSound("assets/category_tap/puzzle_game_organic_wood_block_tone_tap_2.mp3", false);
      blue.x = blue.x -40;
    }
    if ((blue.isTouching(black1)) && (black1.y >= 260) && blue.x >= black1.x){
      playSound("assets/category_tap/puzzle_game_organic_wood_block_tone_tap_2.mp3", false);
      blue.x = blue.x +40;
    }
    //black2 middle
    if ((blue.isTouching(black1)) && (black1.y < 260) && (black1.y >= 150) && blue.x < black1.x){
      playSound("assets/category_tap/puzzle_game_organic_wood_block_tone_tap_2.mp3", false);
      blue.x = blue.x -40;
      black1.y = black1.y +60; 
    }
    if ((blue.isTouching(black1)) && (black1.y < 260) && (black1.y >= 150) && blue.x >= black1.x){
      playSound("assets/category_tap/puzzle_game_organic_wood_block_tone_tap_2.mp3", false);
      blue.x = blue.x +40;
      black1.y = black1.y -60; 
    }
    //truck front
    if ((blue.isTouching(truck)) && (truck.y > 150) && blue.x < truck.x){
      playSound("assets/category_tap/puzzle_game_organic_wood_block_tone_tap_2.mp3", false);
      blue.x = blue.x -40;
      truck.y = truck.y - 15;
    }
    if ((blue.isTouching(truck)) && (truck.y > 150) && blue.x >= truck.x){
      playSound("assets/category_tap/puzzle_game_organic_wood_block_tone_tap_2.mp3", false);
      blue.x = blue.x +40;
      truck.y = truck.y - 15;
    }
    //truck back
    if ((blue.isTouching(truck)) && (truck.y >= 260) && blue.x < truck.x){
      playSound("assets/category_tap/puzzle_game_organic_wood_block_tone_tap_2.mp3", false);
      blue.x = blue.x -40;
    }
    if ((blue.isTouching(truck)) && (truck.y >= 260) && blue.x >= truck.x){
      playSound("assets/category_tap/puzzle_game_organic_wood_block_tone_tap_2.mp3", false);
      blue.x = blue.x +40;
    }
    //black2 middle
    if ((blue.isTouching(truck)) && (truck.y < 260) && (truck.y >= 150) && blue.x < truck.x){
      playSound("assets/category_tap/puzzle_game_organic_wood_block_tone_tap_2.mp3", false);
      blue.x = blue.x -40;
      truck.y = truck.y +60; 
    }
    if ((blue.isTouching(truck)) && (truck.y < 260) && (truck.y >= 150) && blue.x >= truck.x){
      playSound("assets/category_tap/puzzle_game_organic_wood_block_tone_tap_2.mp3", false);
      blue.x = blue.x +40;
      truck.y = truck.y -60; 
    }
  }
  //other cars hit other cars
  //green hit black2 back
  if ((green.isTouching(black2)) && (black2.y < green.y -50) && green.x < black2.x ){
    green.x = green.x -10;
    greenhit = randomNumber(1,2);
    if (greenhit == 1){
      black2.setAnimation("new carcrash");
      black2.velocityX = 4;
      black2.rotationSpeed = 3;
      black2.rotation = -30;
      black2.velocityY = +7;
    }
    if (greenhit == 2){
      green.setAnimation("greencrash1");
      green.velocityX = -4;
      green.rotationSpeed = 3;
      green.rotation = -30;
      green.velocityY = +7;
      counter1 = 1;
    }
  }
  if ((green.isTouching(black2)) && (black2.y < green.y -50) && green.x >= black2.x ){
    green.x = green.x -10;
    greenhit = randomNumber(1,2);
    if (greenhit == 1){
      black2.setAnimation("new carcrash");
      black2.velocityX = -4;
      black2.rotationSpeed = 3;
      black2.rotation = +30;
    }
    if (greenhit == 2){
      green.setAnimation("greencrash1");
      green.velocityX = +4;
      green.rotationSpeed = 3;
      green.rotation = -30;
      green.velocityY = 7;
    }
  }
  //green hit black2 front
  if ((green.isTouching(black2)) && (black2.y >= green.y +60) && green.x < black2.x ){
    green.x = green.x +10;
    greenhit = randomNumber(1,2);
    if (greenhit == 1){
      black2.setAnimation("new carcrash");
      black2.rotationSpeed = 3;
      black2.rotation = +30;
      black2.velocityY = 7;
      black2.velocityX = 7;
    } 
    if (greenhit == 2){
      green.setAnimation("greencrash1");
      green.rotationSpeed = 3;
      green.rotation = +30;
      green.velocityY = 7;
      green.velocityX = -7;
    }
  }
  if ((green.isTouching(black2)) && (black2.y >= green.y +60) && green.x >= black2.x ){
    green.x = green.x +10;
    greenhit = randomNumber(1,2);
    if (greenhit == 1){
      black2.setAnimation("new carcrash");
      black2.rotationSpeed = 3;
      black2.rotation = -30;
      black2.velocityY = 7;
      black2.velocityX = -7;
    }
    if (greenhit == 2){
      green.setAnimation("greencrash1");
      green.rotationSpeed = 3;
      green.rotation = -30;
      green.velocityY = 7;
      green.velocityX = +7;
    }
  }
  //green hit black2 middle
  if ((green.isTouching(black2)) && (black2.y < green.y +60) && (black2.y >= green.y -50) && green.x < black2.x){
    greenhit = randomNumber(1,2);
    if (greenhit == 1){
      black2.setAnimation("new carcrash");
      black2.velocityY = 7;
      black2.velocityX = 3;
    }
    if (greenhit == 2){
      green.setAnimation("greencrash1");
      green.velocityY = 7;
      green.velocityX = -3;
    }
  }
  if ((green.isTouching(black2)) && (black2.y < green.y +60) && (black2.y >= green.y -50) && green.x >= black2.x){
    greenhit = randomNumber(1,2);
    if (greenhit == 1){
      black2.setAnimation("new carcrash");
      black2.velocityY = 7;
      black2.velocityX = -3;
    }
    if (greenhit == 2){
      green.setAnimation("greencrash1");
      green.velocityY = 7;
      green.velocityX = 3;
    }
  }
  
  
  
  //green hit yellow back
  if ((green.isTouching(yellow)) && (yellow.y < green.y -50) && green.x < yellow.x ){
    green.x = green.x -10;
    greenhit = randomNumber(1,2);
    if (greenhit == 1){
      yellow.setAnimation("yellowcrash1");
      yellow.velocityX = 4;
      yellow.rotationSpeed = 3;
      yellow.rotation = -30;
      yellow.velocityY = +7;
    }
    if (greenhit == 2){
      green.setAnimation("greencrash1");
      green.velocityX = -4;
      green.rotationSpeed = 3;
      green.rotation = -30;
      green.velocityY = +7;
    }
  }
  if ((green.isTouching(yellow)) && (yellow.y < green.y -50) && green.x >= yellow.x ){
    green.x = green.x -10;
    greenhit = randomNumber(1,2);
    if (greenhit == 1){
      yellow.setAnimation("yellowcrash1");
      yellow.velocityX = -4;
      yellow.rotationSpeed = 3;
      yellow.rotation = +30;
      yellow.velocityY = +7;
    }
    if (greenhit == 2){
      green.setAnimation("greencrash1");
      green.velocityX = +4;
      green.rotationSpeed = 3;
      green.rotation = +30;
      green.velocityY = 7;
    }
  }
  //green hit yellow front
  if ((green.isTouching(yellow)) && (yellow.y >= green.y +60) && green.x < yellow.x ){
    green.x = green.x +10;
    greenhit = randomNumber(1,2);
    if (greenhit == 1){
      yellow.setAnimation("yellowcrash1");
      yellow.rotationSpeed = 3;
      yellow.rotation = +30;
      yellow.velocityY = 7;
      yellow.velocityX = 7;
    } 
    if (greenhit == 2){
      green.setAnimation("greencrash1");
      green.rotationSpeed = 3;
      green.rotation = +30;
      green.velocityY = 7;
      green.velocityX = -7;
    }
  }
  if ((green.isTouching(yellow)) && (yellow.y >= green.y +60) && green.x >= yellow.x ){
    greenhit = randomNumber(1,2);
    green.x = green.x +10;
    if (greenhit == 1){
      yellow.setAnimation("yellowcrash1");
      yellow.rotationSpeed = 3;
      yellow.rotation = -30;
      yellow.velocityY = 7;
      yellow.velocityX = -7;
    }
    if (greenhit == 2){
      green.setAnimation("greencrash1");
      green.rotationSpeed = 3;
      green.rotation = -30;
      green.velocityY = 7;
      green.velocityX = +7;
    }
  }
  //green hit yellow middle
  if ((green.isTouching(yellow)) && (yellow.y < green.y +60) && (yellow.y >= green.y -50) && green.x < yellow.x){
    greenhit = randomNumber(1,2);
    if (greenhit == 1){
      yellow.setAnimation("yellowcrash1");
      yellow.velocityY = 7;
      yellow.velocityX = 3;
    }
    if (greenhit == 2){
      green.setAnimation("greencrash1");
      green.velocityY = 7;
      green.velocityX = -3;
    }
  }
  if ((green.isTouching(yellow)) && (yellow.y < green.y +60) && (black2.y >= green.y -50) && green.x >= yellow.x){
    greenhit = randomNumber(1,2);
    if (greenhit == 1){
      yellow.setAnimation("yellowcrash1");
      yellow.velocityY = 7;
      yellow.velocityX = -3;
    }
    if (greenhit == 2){
      green.setAnimation("greencrash1");
      green.velocityY = 7;
      green.velocityX = 3;
    }
  }

  //lightsred
  if (everythingaboutblue >= 10){
    light.visible = true;
  }
  if (everythingaboutblue == 15){
    playSound("assets/category_bell/hollow_bell_notification.mp3", false);
  }
  //lightyellow
  if (everythingaboutblue >= 40){
    light.setAnimation("lightyellow");
  }
  if (everythingaboutblue == 45){
    playSound("assets/category_bell/hollow_bell_notification.mp3", false);
  }
  //lightgreen
  if (everythingaboutblue >= 70){
    light.setAnimation("lightgreen");
  }
  if (everythingaboutblue == 75){
    playSound("assets/category_bell/hollow_bell_notification.mp3", false);
  }
  //gamestart
  if (everythingaboutblue >= 90){
    if (everythingaboutblue == 91){
      playSound("assets/category_bell/vibrant_game_correct_answer_1.mp3", false);
    }
    if (speed < 60){
      speed = speed +1;
    } else {
      speed = randomNumber(59,61);
    }
    light.visible = 0;
    road.setAnimation("road2");
    grass1.velocityY = +7;
    grass2.velocityY = +7;
    grass3.velocityY = +7;
    grass4.velocityY = +7;
    coin.velocityY = +7;
    grass5.velocityY = +7;
    grass6.velocityY = +7;
    grass7.velocityY = +7;
    grass8.velocityY = +7;
    jetpack.velocityY = +7;
    truck.velocityY = +14;
    start.velocityY = +7;
    green.velocityY = -randomNumber(+1.8, 2.5);
    yellow.velocityY = randomNumber(0.4,1);
    obstacle2.velocityY = +7;
    obstacle1.velocityY = +7;
    black2.velocityY = -3;
    diamond1.velocityY = +7;
    diamond2.velocityY = +7;
    diamond3.velocityY = +7;
    //left
    if (keyDown("left") || keyDown("a")){
      blue.x = blue.x - 5;
    }
    //right
    if (keyDown("right")|| keyDown("d")){
      blue.x = blue.x + 5;
    }
    //mouse control
    if (keyWentDown("M")){
      backgroundtext2 = backgroundtext2 +1;
    }
    if (backgroundtext2 >= 1){
      blue.x = World.mouseX;
    }
    if (backgroundtext2 >= 2){
      backgroundtext2 = 0;
    }
    
    //S
    if (keyWentDown("S") && supercharge <= 60 && score >= 30){
      score -= 30;
      supercharge = 60;
    }
    
    //faster
    if ((keyWentDown("space")) && (supercharge >= 10)){
      playSound("assets/category_bell/vibrant_game_correct_answer_1.mp3", false);
    }
    if ((keyDown("space")) && (supercharge >= 10)){
      if (speed < 110){
        speed = speed +10;
      } else {
        speed = randomNumber(109,110);
      }
      jet = jet -0.1;
      faster2();
      logo.visible = 1;
      logo.x = blue.x;
      logo.y = blue.y -35;
    } else {
      logo.visible = 0;
    }
  }
  
  //black1 out of screen
  black1.velocityY = + 14;
  if (black1.y >= 460){
    black1.y = randomNumber(-5000,-7000);
    black1out = randomNumber(1,2);
    if (black1out == 1){
    black1.x = 160;
    }
    if (black1out == 2){
    black1.x = 75;
    
    }
  }
  //truck out of screen
  if (truck.y >= 460){
    truck.y = randomNumber(-5000,-7000);
    truckout = randomNumber(1,2);
    if (truckout == 1){
    truck.x = 160;
    }
    if (truckout == 2){
    truck.x = 75;
    }
  }
  //black2 out of screen
  if (black2.y <= -460){
    black2.y = randomNumber(2000,3000);
    black2out = randomNumber(1,2);
    if (black2out == 1){
    black2.x = 250;
    }
    if (black2out == 2){
    black2.x = 330;
    }
  }
  //yellow out of screen
  if (yellow.y <= -460){
    
    yellowout = randomNumber(1,2);
    if (yellowout == 1){
    yellow.x = 250;
    }
    if (yellowout == 2){
    yellow.x = 330;
    }
  }  
    if (yellow.y >= 460){
    yellowout = randomNumber(1,2);
    if (yellowout == 1){
      yellow.x = 250;
    }
    if (yellowout == 2){
      yellow.x = 330;
    }
    yellow.rotationSpeed = 0;
    yellow.rotation = 0;
  }
  //green out of screen
  if (green.y <= -50){
    greenout = randomNumber(1,2);
    if (greenout == 1){
    green.x = 250;
    }
    if (greenout == 2){
    green.x = 330;
    }
    green.rotation = 0;
    
  }  
  if (green.y >= 800){
    greenout = randomNumber(1,2);
    if (greenout == 1){
    green.x = 250;
    }
    if (greenout == 2){
    green.x = 330;
    }
    green.rotationSpeed = 0;
    green.rotation = 0;
  }
  //obstacle1 out of screen
  if (obstacle1.y >= 430){
    obstacle1.x = randomNumber(100,300);
    obstacle1.y = randomNumber(-2000,-3000);
  }
  if (obstacle2.y >= 430){
    obstacle2.x = randomNumber(100,300);
    obstacle2.y = randomNumber(-2000,-3000);
  }
  
  //grass1 out of screen
  if (grass1.y >= 430){
    grass1.y = randomNumber(-20,-40);
  }
  //grass2 out of screen
  if (grass2.y >= 430){
    grass2.y = randomNumber(-40,-60);
  }
  //grass3 out of screen
  if (grass3.y >= 430){
    grass3.y = randomNumber(-40,-60);
  }
  //grass4 out of screen
  if (grass4.y >= 430){
    grass4.y = randomNumber(-40,-60);
  }
  //grass5 out of screen
  if (grass5.y >= 430){
    grass5.y = randomNumber(-20,-40);
  }
  //grass6 out of screen
  if (grass6.y >= 430){
    grass6.y = randomNumber(-40,-60);
  }
  //grass7 out of screen
  if (grass7.y >= 430){
    grass7.y = randomNumber(-40,-60);
  }
  //grass8 out of screen
  if (grass8.y >= 430){
    grass8.y = randomNumber(-40,-60);
  }
  //coin out of screen
  if (coin.y >= 430){
    coin.y = randomNumber(-40,-60);
    coin.x = randomNumber(40,360);
  }
  //jetpack out of screen
  if (jetpack.y >= 440){
    jetpack.y = randomNumber(-300,-500);
    jetpack.x = randomNumber(60,340);
  }
  //diamonds out of screen
  if (diamond1.y >= 430){
    whatdiamondslooklike = randomNumber(1,4);
    if (whatdiamondslooklike == 1){
      diamonds1();
    }
    if (whatdiamondslooklike == 2){
      diamonds2();
    }
    if (whatdiamondslooklike == 3){
      diamonds3();
    }
    if (whatdiamondslooklike == 4){
      diamonds4();
    }
  }
  if ((diamond1.y < -20 && diamond2.y < -20 && diamond2.y < -20)){
    diamond1.y = diamond2.y;
    diamond2.y = diamond3.y;
  }
  //diamonds out of screen
  if (diamond2.y >= 430){
    whatdiamondslooklike = randomNumber(1,4);
    if (whatdiamondslooklike == 1){
      diamonds1();
    }
    if (whatdiamondslooklike == 2){
      diamonds2();
    }
    if (whatdiamondslooklike == 3){
      diamonds3();
    }
    if (whatdiamondslooklike == 4){
      diamonds4();
    }
  }
  //diamonds out of screen
  if (diamond3.y >= 430){
    whatdiamondslooklike = randomNumber(1,4);
    if (whatdiamondslooklike == 1){
      diamonds1();
    }
    if (whatdiamondslooklike == 2){
      diamonds2();
    }
    if (whatdiamondslooklike == 3){
      diamonds3();
    }
    if (whatdiamondslooklike == 4){
      diamonds4();
    }
  }
  superspeed.x = blue.x;
  superspeed.y = blue.y +10;
  
  //useful
  if (jet <= 0){
    supercharge = 0;
  }
  
  //blue touch diamond
  if (blue.isTouching(diamond1)){
    playSound("assets/category_bell/choose_background.mp3", false);
    superpower = randomNumber(1,6);
    diamond1.y = -3000;
    Iamyoursuperpowers.visible = 0;
    if (superpower == 1){
      howlong = 500;
    }
  }
  if (blue.isTouching(diamond2)){
    playSound("assets/category_bell/choose_background.mp3", false);
    howlongitwilltake = 20;
    superpower = randomNumber(1,6);
    diamond2.y = -3000;
    Iamyoursuperpowers.visible = 1;
    if (superpower == 1){
      howlong = 500;
    }
  }
  if (blue.isTouching(diamond3)){
    playSound("assets/category_bell/choose_background.mp3", false);
    howlongitwilltake = 20;
    superpower = randomNumber(1,6);
    diamond3.y = -3000;
    Iamyoursuperpowers.visible = 1;
    if (superpower == 1){
      howlong = 500;
    }
  }
  howlongitwilltake = howlongitwilltake-1;
  if ((superpower == 1 && howlongitwilltake == 0)){
    playSound("assets/category_whoosh/alien_ship_flyby_whoosh_6.mp3", false);
  }
  if ((superpower == 1 && howlongitwilltake <= 0)){
    if (speed < 135){
      speed = speed +35;
    } else {
      speed = randomNumber(134,136);
    }
    Iamyoursuperpowers.visible = 0;
    superspeed.visible = 1;
    howlong = howlong -1;
    faster2();
    faster2();
    faster2();
    if (howlong <= 0){
      superpower = 0;
    }
  }else{
    superspeed.visible = 0;
  }
  if ((superpower == 2 && howlongitwilltake <= 0)){
    live = live +1; 
    superpower = 0;
    Iamyoursuperpowers.visible = 0;
  }
  if ((superpower == 3 && howlongitwilltake <= 0)){
    score = score +10;
    superpower = 0;
    Iamyoursuperpowers.visible = 0;
  }
  if ((superpower == 4 && howlongitwilltake <= 0)){
    shellhit1 = 0;
    shell1.visible = 1;
    if (keyWentDown("up") || keyWentDown("w")){
      playSound("assets/category_explosion/air_explode_bonus_5.mp3", false);
      shell1.velocityY = -5;
      shellhit1 = 1;
      superpower = 0;
    }
    if (keyWentDown("down") || keyWentDown("s")){
      playSound("assets/category_explosion/air_explode_bonus_5.mp3", false);
      shell1.velocityY = +15;
      shellhit1 = 1;
      superpower = 0;
    }
    Iamyoursuperpowers.visible = 0;
  }
  if ((superpower == 5 && howlongitwilltake <= 0 && place >1)){
    shellhit2 = 0;
    shell2.visible = 1;
    if (keyWentDown("up") || keyWentDown("w")){
      playSound("assets/category_explosion/8bit_explosion.mp3", false);
      if ((green.y < blue.y && green.x < yellow.x)){
        green.y = 20;
        shell1.visible = 0;
        superpower = 0;
      }
      if ((yellow.y < blue.y  && yellow.x < green.x)){
        yellow.y = 20;
        shell1.visible = 0;
        superpower = 0;
      }
    }
    if (ifshellhit == 1){
      green.velocityY = green.velocityY +10;
    }
    if (ifshellhit == 2){
      yellow.velocityY = yellow.velocityY +10;
    }
    Iamyoursuperpowers.visible = 0;
  }
  if ((superpower == 6 && howlongitwilltake <= 0)){
    bomb.visible = 1;
    Iamyoursuperpowers.visible = 0;
  }
  if ((bomb.visible == 1 && bomb.y == blue.y -80)){
    if (keyWentDown("up") || keyWentDown("w")){
      bombhit1 = 1;
      bomb.velocityY = -5;
    }
    if (keyWentDown("down") || keyWentDown("s")){
      bombhit1 = 1;
      bomb.velocityY = +15;
    }
  }
  // shells
  if (shellhit1 == 0){
    shell1.x = blue.x -60;
    shell1.y = blue.y;
  }
  if (shellhit2 == 0){
    shell2.x = blue.x +60;
    shell2.y = blue.y;
  }
  if (bombhit1 ==0){
    bomb.x = blue.x;
    bomb.y = blue.y - 80;
  }
  //shell hit other cars
  if ((shell1.isTouching(green) && shell1.visible == 1 )){
    playSound("assets/category_bell/quiet_belloctave_notification.mp3", false);
    green.setAnimation("greencrash1");
    green.velocityY = +7;
    shell1.y = blue.y;
    shell1.x = blue.x -60;
    shellhit1 = 0;
    shell1.visible = 0;
    perfecthit1.visible = 1;
  }else{
    perfecthit1.visible = 0;
  }
  if ((bomb.isTouching(green) && bomb.visible == 1 )){
    bombhit1 = 0;
    superpower = 0;
    bomb.visible = 0;
    green.setAnimation("greencrash1");
    green.velocityY = +7;
  }
  
  //blue touch jet
  if (blue.isTouching(jetpack)){
    playSound("assets/category_collect/energy_bar_recharge_2.mp3", false);
    jetpack.y = randomNumber(-300,-400);
    jetpack.x = randomNumber(60,340);
    supercharge = supercharge +1;
    jet = jet + 3;
  }
  if ((blue.isTouching(jetpack)) && (supercharge >= 10) && (jet >= 60)){
    jetpack.y = randomNumber(-400,-600);
    jetpack.x = randomNumber(60,340);
  }
  //blue touch obstacle1
  if ((blue.isTouching(obstacle1) && everythingaboutblue <= 20000)){
    playSound("assets/category_digital/failure.mp3", false);
    obstacle1.x = randomNumber(100,300);
    obstacle1.y = randomNumber(-6000,-8000);
    live = live -1;
  }
  //blue touch obstacle2
  if ((blue.isTouching(obstacle2) && everythingaboutblue <= 20000)){
    playSound("assets/category_digital/failure.mp3", false);
    obstacle2.x = randomNumber(100,300);
    obstacle2.y = randomNumber(-6000,-8000);
    live = live -1;
  }
  //green touch obstacle1
  if ((green.isTouching(obstacle1) && everythingaboutblue <= 20000)){
    obstacle1.x = randomNumber(100,300);
    obstacle1.y = randomNumber(-6000,-8000);
  }
  //green touch obstacle2
  if (green.isTouching(obstacle2)){
    obstacle2.x = randomNumber(100,300);
    obstacle2.y = randomNumber(-6000,-8000);
  }
  //yellow touch obstacle1
  if (yellow.isTouching(obstacle1)){
    obstacle1.x = randomNumber(100,300);
    obstacle1.y = randomNumber(-6000,-8000);
  }
  //yellow touch obstacle2
  if (yellow.isTouching(obstacle2)){
    obstacle2.x = randomNumber(100,300);
    obstacle2.y = randomNumber(-6000,-8000);
  }
  //black2 touch obstacle1
  if (black2.isTouching(obstacle1)){
    obstacle1.x = randomNumber(100,300);
    obstacle1.y = randomNumber(-6000,-8000);
  }
  //black2 touch obstacle2
  if (black2.isTouching(obstacle2)){
    obstacle2.x = randomNumber(100,300);
    obstacle2.y = randomNumber(-6000,-8000);
  }
  //black1 touch obstacle1
  if (black1.isTouching(obstacle1)){
    obstacle1.x = randomNumber(100,300);
    obstacle1.y = randomNumber(-6000,-8000);
  }
  //black1 touch obstacle2
  if (black1.isTouching(obstacle2)){
    obstacle2.x = randomNumber(100,300);
    obstacle2.y = randomNumber(-6000,-8000);
  }
  //truck touch obstacle1
  if (truck.isTouching(obstacle1)){
    obstacle1.x = randomNumber(100,300);
    obstacle1.y = randomNumber(-6000,-8000);
  }
  //truck touch obstacle2
  if (truck.isTouching(obstacle2)){
    obstacle2.x = randomNumber(100,300);
    obstacle2.y = randomNumber(-6000,-8000);
  }
  //blue touch jet when full
   if (blue.isTouching(jetpack) && (jet >= 60)){
    jetpack.y = randomNumber(-400,-600);
    jetpack.x = randomNumber(60,340);
  }
  //blue touch coin
  if (blue.isTouching(coin)){
    playSound("assets/category_collect/collect_item_bling_1.mp3", false);
    coin.y = randomNumber(-40,-60);
    coin.x = randomNumber(40,360);
    score = score +1;
  }
  
  //battery
  if (jet >= 3){
    graphic.setAnimation("empty2");
  }
  if (jet >= 6){
    graphic.setAnimation("low1");
  }
  if (jet >= 9){
    graphic.setAnimation("low2");
  }
  if (jet >= 12){
    graphic.setAnimation("low3");
  }
  if (jet >= 15){
    graphic.setAnimation("m1");
  }
  if (jet >= 18){
    graphic.setAnimation("m2");
  }
  if (jet >= 21){
    graphic.setAnimation("m3");
  }
  if (jet >= 24){
    graphic.setAnimation("m4");
  }
  if (jet >= 27){
    graphic.setAnimation("high1");
  }
  if (jet >= 30){
    graphic.setAnimation("high2");
  }
  if (jet >= 33){
    graphic.setAnimation("high3");
  }
  if (jet >= 36){
    graphic.setAnimation("high4");
  }
  if (jet >= 39){
    graphic.setAnimation("high5");
  }
  if (jet >= 42){
    graphic.setAnimation("high6");
  }
  if (jet >= 45){
    graphic.setAnimation("high7");
  }
  if (jet >= 48){
    graphic.setAnimation("high8");
  }
  if (jet >= 51){
    graphic.setAnimation("high9");
  }
  if (jet >= 54){
    graphic.setAnimation("high10");
  }
  if (jet >= 57){
    graphic.setAnimation("high11");
  }
  if (jet >= 60){
    graphic.setAnimation("full");
  }
  
  //blue off road when live >1
  if ((blue.x >= 360) || (blue.x <= 40) && (live > 1)){
    slowdown();
    speed = 40;
  }
  //blue off road when live <= 1
  if ((blue.x >= 360) || (blue.x <= 40)  && (live <= 1)){
    slowdown2();
    speed = 30;
  }

  if (green.x <= -40 || green.x >= 440){
    green.velocityX = 0;
    green.velocityY = +7;
  }
  
  if (yellow.x >= 440 || yellow.x <= -40){
    yellow.velocityX = 0;
    yellow.velocityY = yellow.velocityY +7;
    
  }
  
  //yellow & green speed
  if (score >= 100){
    green.velocityY = green.velocityY + randomNumber(1.8, 2);
  }
  
  if (score >= 15){
    yellow.velocityY = yellow.velocityY - randomNumber(2, 3);
  }
  
  //moving1
  if (everythingaboutblue >= 2000){
    if (speed < 70){
      speed = speed +10;
    } else {
      speed = randomNumber(69,71);
    }
    grass.setAnimation("dirt");
    grass1.setAnimation("grassbrown1");
    grass2.setAnimation("grassbrown2");
    grass5.setAnimation("grassbrown1");
    grass6.setAnimation("grassbrown2");
    faster();
    everythingaboutblue = everythingaboutblue + 1.13833;
    road.setAnimation("road4");
  }
  
  //moving2
  if (everythingaboutblue >= 4000){
    if (everythingaboutblue < 4300){
      sign1.visible = 1;
    } else {
      sign1.visible = 0;
    }
    grass.setAnimation("sand");
    grass1.setAnimation("grassbrown1");
    grass2.setAnimation("grassbrown2");
    grass3.setAnimation("cactus");
    grass4.setAnimation("wheat");
    grass5.setAnimation("grassbrown1");
    grass6.setAnimation("grassbrown2");
    grass7.setAnimation("cactus");
    grass8.setAnimation("wheat");
    faster();
    everythingaboutblue = everythingaboutblue + 1.27666;
  }
  
  //moving2
  if (everythingaboutblue >= 6000){
    if (speed < 80){
      speed = speed +10;
    } else {
      speed = randomNumber(79,82);
    }
    grass.setAnimation("redsand");
    faster();
    everythingaboutblue = everythingaboutblue + 1.41499;
    road.setAnimation("road5");
  }
  
  //moving3
  if (everythingaboutblue >= 8000){
    if (everythingaboutblue < 8300){
      sign1.visible = true;
    }else{
      sign1.visible = 0;
    }
    grass.setAnimation("snow");
    grass3.visible = 0;
    grass4.visible = 0;
    grass7.visible = 0;
    grass8.visible = 0;
    faster();
    everythingaboutblue = everythingaboutblue + 1.55332;
  }
  
  //moving4
  if (everythingaboutblue >= 10000){
    if (speed < 90){
      speed = speed +10;
    } else {
      speed = randomNumber(89,92);
    }
    grass.setAnimation("lake");
    grass1.visible = 0;
    grass2.visible = 0;
    grass5.visible = 0;
    grass6.visible = 0;
    faster();
    everythingaboutblue = everythingaboutblue +1.69165;
    road.setAnimation("road6");
  }
  
  //moving5
  if (everythingaboutblue >= 12000){
    if (everythingaboutblue < 12300){
      sign1.visible = true;
    }else{
      sign1.visible = 0;
    }
    grass1.visible = 1;
    grass2.visible = 1;
    grass3.visible = 1;
    grass4.visible = 1;
    grass5.visible = 1;
    grass6.visible = 1;
    grass7.visible = 1;
    grass8.visible = 1;
    grass.setAnimation("grass");
    grass1.setAnimation("grass1");
    grass2.setAnimation("grass2");
    grass3.setAnimation("grass3");
    grass4.setAnimation("seed");
    grass5.setAnimation("grass1");
    grass6.setAnimation("grass2");
    grass7.setAnimation("grass3");
    grass8.setAnimation("seed");
    everythingaboutblue = everythingaboutblue +1.83;
  }
  
  //moving6
  if (everythingaboutblue >= 16000 && everythingaboutblue < 16300){
    sign1.visible = true;
  }else{
    sign1.visible = 0;
  }
  if (everythingaboutblue >= 16000){
    if (speed < 100){
      speed = speed +10;
    } else {
      speed = randomNumber(99,102);
    }
  }
  
  //moving7
  if (everythingaboutblue >= 19000){
    finishline.velocityY = + 12;
    green.velocityY = 0;
    yellow.velocityY = 0;
  }
  
  //moving8
  if (everythingaboutblue >= 20000){
    blackbackground.visible = 1;
    slowdown();
    finish = 1;
    meadel.visible = 1;
    if (place == 1){
      green.x = 300;
      yellow.x = 400;
    }
    if (place == 2){
      meadel.setAnimation("silver");
      green.y = 0;
      yellow.y = 300;
    }
    if (place == 3){
      meadel.setAnimation("copper");
      green.x = 0;
      yellow.x = 10;
    }
    thisiscool = 0;
  }
  
  //if your live <= 1
  if (live <= 1){
    if(counter1 ==1){
      blue.setAnimation("blackcrash1");
    }
    if(counter2 ==1){
      blue.setAnimation("greencrash1");
    }
    if(counter3 ==1){
      blue.setAnimation(" bluecrash1");
    }
    if(counter4 ==1){
      blue.setAnimation("truckcrash1");
    }
    if(counter5 ==1){
      blue.setAnimation("new carcrash");
    }
    slowdown();
  }else{
    if(counter1 ==1){
      blue.setAnimation("black");
    }
    if(counter2 ==1){
      blue.setAnimation("green");
    }
    if(counter3 ==1){
      blue.setAnimation(" blue");
    }
    if(counter4 ==1){
      blue.setAnimation("truck");
    }
    if(counter5 ==1){
      blue.setAnimation("new car");
    }
  }
  
  //if your live <= 0
  if (live <= 0){
    var gameover = createSprite(200,200);
    gameover.setAnimation("gameover");
    gameover.scale = 1.8;
  }
  
  //the #1 code for calculating your place 
  if (blue.y == green.y){
    place = 1;
  }
  if (green.y < blue.y && yellow.y > blue.y){
    place = 2;
  }else{
    place = 1;
  }
  
  if (yellow.y < blue.y && green.y > blue.y){
    place = 2;
  }else{
    place = 1;
  }
  
  if (yellow.y < blue.y && green.y < blue.y){
    place = 3;
  }else{
    place = 2;
  }
  if (yellow.y > blue.y && green.y > blue.y){
    place = 1;
  }
  if ((score >= 30 && keyWentDown("l"))){
    live = live +3;
    score = score -30;
  }
  
  // draw all things
  drawSprites();
  
  //win
  if (everythingaboutblue == 20000){
    playSound("assets/category_music/fun_game_win_musical_4.mp3", false);
  }if (everythingaboutblue >= 20000){
    if (place == 2){
      textSize(30);
      fill(rgb(192, 192, 192));
      text("Nice Job!",140,100);
      text("Second Place!",110,300);
    }
    if (place == 3){
      textSize(30);
      fill(rgb(184, 134, 11));
      text("Nice Try!",140,100);
      text("Third Place!",120,300);
    }
    if (place == 1){
      textSize(30);
      fill(rgb(255, 215, 0));
      text("Perfect!",170,100);
      text("First Place!",120,300);
    }
  }
  
  //signs
  if ((everythingaboutblue >= 4000 && everythingaboutblue < 4300)){
    textSize(25);
    fill("white");
    text("1/4",180,30);
  }
  if ((everythingaboutblue >= 8000 && everythingaboutblue < 8300)){
    textSize(25);
    fill("white");
    text("1/2",180,30);
  }
  if ((everythingaboutblue >= 12000 && everythingaboutblue < 12300)){
    textSize(25);
    fill("white");
    text("3/4",180,30);
  }
  if ((everythingaboutblue >= 16000 && everythingaboutblue < 16300)){
    textSize(20);
    fill("white");
    text("Last Lap",170,30);
  }
  
  //information about you
  if (thisiscool == 1){
    textSize(20);
    fill("white");
    text("SCORE: " +score, 15, 20);
    text("LIVE: " +live, 15, 50 );
    text("PLACE: " + place, 280, 20 );
    textSize(40);
    text(speed, 320, 360 );
  }
  
  //instructions
  if (backgroundtext == 1){
    textFont("comfortaa");
    textSize(25);
    fill("white");
    text("CHOOSE YOUR VEHICLE", 50, 180);
    textSize(20);
   
   
    textSize(18);
    text("Roadster Gen 2",220,225);
    textSize(20);
  text("space ship  Model X     Model S      jet", 25, 370);
  
  }
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
